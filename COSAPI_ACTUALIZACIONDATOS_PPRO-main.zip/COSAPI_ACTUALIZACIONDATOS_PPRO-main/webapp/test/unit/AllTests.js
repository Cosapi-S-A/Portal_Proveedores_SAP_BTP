sap.ui.define([
	"nscosapi/actualizacionproveedor/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
