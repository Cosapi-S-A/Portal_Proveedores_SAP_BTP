/* global QUnit */

sap.ui.require(["ns/cosapi/actualizacionproveedor/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
