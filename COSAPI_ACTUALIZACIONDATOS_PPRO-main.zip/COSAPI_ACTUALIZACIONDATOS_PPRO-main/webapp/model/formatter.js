sap.ui.define([
],
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function () {
        "use strict";

        return {
            formatDateSunat: function (date) {
                if (date === "" || date === null)
                    return null;
                return date.replaceAll("/", ".");
            },

            getFormatDataSunat: function (xmlDoc) {
                const oReturn = {
                    message: null
                };
                // Obtener el contenido del elemento <return>
                var returnContent = xmlDoc.getElementsByTagName("return")[0].textContent;

                // Procesar la cadena de texto obtenida para extraer los datos clave-valor
                var keyValuePairs = returnContent.split("|");
                var result = {};

                keyValuePairs.forEach(function (pair) {
                    var keyValue = pair.split("=");
                    var key = keyValue[0];
                    var value = keyValue[1];
                    result[key] = value;
                });

                // Ahora puedes acceder a los datos que necesitas en el objeto 'result'
                if (keyValuePairs[0] == "") {
                    oReturn.type = "E"
                    oReturn.message = "Por favor, revisar las credenciales al consumir la API"

                } else {
                    if (result.status_id != 1) {
                        oReturn.type = "E"
                        oReturn.message = result.status_msg
                    } else {
                        oReturn.type = "S"
                        oReturn.data = result
                        oReturn.data.razonSocial = result.n1_alias
                        oReturn.data.direccion = result.n2_dir_fiscal
                        oReturn.data.condicion = result.n1_condicion
                        oReturn.data.estado = result.n1_estado
                        oReturn.data.fec_actividad = result.n2_init_actv ? result.n2_init_actv.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$1.$2.$3") : ""
                        oReturn.data.nombre_comercial = result.n2_nom_comer
                    }
                }
                return (oReturn);
            },

            formatoListaReferencia: function (aData) {
                let aRef = []
                for (let i = 0; i < aData.length; i++) {
                    let oData = aData[i]
                    let iPos = i + 1
                    let oRef = {
                        "Entfinancpos": iPos,
                        "EmailSec": oData.EmailSec,
                        "Taxnumxl": oData.Taxnumxl,
                        "Correlativo": oData.Correlativo,
                        "IdEnt": oData.IdEnt,
                        "Land1": oData.Land1,
                        "NombreEnt": oData.NombreEnt,
                        "NombreSect": oData.NombreSect,
                        "TelSec": oData.TelSec,
                        "LineaCredito": oData.LinAproS == "X" ? "S/" : "USD", //Campo solo vista tabla
                        "LinAproS": oData.LinAproS,
                        "LinAproD": oData.LinAproD,
                        "Monto": oData.Monto
                    }
                    aRef.push(oRef)
                }

                return aRef
            },

            getFormatCialExample: function () {
                return {
                    "segment_id": "669e81c9669c0afaf5dfae4d",
                    "data": {
                        "fields_data": [

                        ],
                        "companies": [
                            {
                                "duns": "123456789",
                                "emails": [

                                ],
                                "questionnaireEmails": [

                                ],
                                "comment": "datos de contacto"
                            }
                        ]
                    }
                }
            },

            getFormatCial: function (response) {
                const datacial = {
                    "segment_id": response.SegmentoId,
                    "data": {
                        "companies": [
                            {
                                "address": response.Direccion,
                                "city": response.Ciudad,
                                "country": response.Pais,
                                "legal_name": response.NombreLegal,
                                "postal_code": response.CodigoPostal,
                                "tax_id": response.NumeroNif,
                                "telephone": response.Telefono,
                                "emails": [],
                                "questionnaireEmails": [],
                                "comment": response.NombreContComer + "," + response.TelefonoContComer
                            }
                        ]
                    }
                };
                if (response.Dums !== "") {
                    let emailsAux = [];
                    emailsAux.push(response.Correo);

                    datacial.data = {
                        fields_data: [],
                        companies: [{
                            "duns": response.Dums,
                            "emails": emailsAux,
                            "questionnaireEmails": [

                            ],
                            "comment": response.NombreContComer + "," + response.TelefonoContComer
                        }]
                    };
                }
                return datacial;
            }
        };
    });
