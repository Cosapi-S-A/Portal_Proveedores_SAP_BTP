sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ns.cosapi.creacionlistadofactura.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  