/* global QUnit */

sap.ui.require(["ns/cosapi/cargamasivaproveedor/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
