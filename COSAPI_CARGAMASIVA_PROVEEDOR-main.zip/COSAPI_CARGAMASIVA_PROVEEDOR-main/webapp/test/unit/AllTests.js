sap.ui.define([
	"nscosapi/cargamasivaproveedor/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
