sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
], function(
	Controller,
	UIComponent
) {
	"use strict";

	return Controller.extend("ns.cosapi.cargamasivaproveedor.controller.BaseController", {

        getRouter : function () {
            return UIComponent.getRouterFor(this);
        },

        /**
         * Convenience method for getting the view model by name.
         * @public
         * @param {string} [sName] the model name
         * @returns {sap.ui.model.Model} the model instance
	    */
        getModel : function (sName) {
            return this.getView().getModel(sName);
        },

        /**
         * Convenience method for setting the view model.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel : function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Getter for the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getResourceBundle : function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        readEntity: function(odataModel,path,parameters){
            return new Promise((resolve,reject) => {
                odataModel.read(path,{
                    filters: parameters.filters,
                    urlParameters: parameters.urlParameters,
                    success: resolve,
                    error: reject
                });
            });
        },

        createEntity:function(odataModel,path,data){
            return new Promise((resolve,reject)=>{
                odataModel.create(path,data,{
                    success:resolve,
                    error:reject
                });
            });
        },

        updateEntity:function(odataModel,path,data){
            return new Promise((resolve,reject)=>{
                odataModel.update(path,data,{
                    success:resolve,
                    error:reject
                });
            });
        },
        
        deleteEntity:function(odataModel,path,data){
            return new Promise((resolve,reject)=>{
                odataModel.remove(path,{
                    success:resolve,
                    error:reject
                });
            });
        },

        callFunction: function(odataModel,path,parameters){
            return new Promise((resolve,reject) => {
                odataModel.callFunction(path,{
                    urlParameters: parameters,
                    success: resolve,
                    error: reject
                });
            });
        },

        getBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);
            return appModulePath;
        },

        _formatDate: function(date){
            if(date !== "" && date && date instanceof Date) return date.toISOString().split("T")[0]
            else return date
        },

        _formatDateCierre: function(date){
            date.setDate(date.getDate() + 1);
            if(date !== "" && date && date instanceof Date) return date.toISOString().split("T")[0]
            else return date
        },

        _excelDateToJSDate: function(date){
            return new Date(Date.UTC(0, 0, date - 1));
        },

        _validarExisteEmailOrNif: function (value, parametro) {
            return new Promise((resolve,reject) => {
  
                let that = this;
                let xhr = new XMLHttpRequest();
                xhr.withCredentials = true;
                xhr.addEventListener("readystatechange", function () {
                    if (this.readyState === 4) {
                        var userData = JSON.parse(this.responseText);
                        sap.ui.core.BusyIndicator.hide()
                        if (userData.totalResults == 0) {
                            resolve(false)
                        } else {
                            resolve(true)
                        }
                    }
                });
                
                let url = ""; 
                url = this.getBaseURL() + `/scim/Users?filter=${parametro} eq \"` + value + "\"";
                xhr.open("GET", url, false);
                xhr.send();

            });
        }

	});
});