sap.ui.define([
    "./BaseController",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
	"sap/m/Button",
	"sap/m/Dialog",
	'sap/m/Bar',
	"sap/m/Text",
	'sap/m/MessageItem',
	'sap/m/MessageView',
    'sap/m/MessageToast'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (
        BaseController,
        MessageBox,
        JSONModel,
        Filter,
        FilterOperator,
        Button, 
        Dialog,
        Bar, 
        Text, 
        MessageItem, 
        MessageView,
        MessageToast
    ) {
        "use strict";
        let oModelExcel,
            oModelListaFunciones,
            ZMMGS_PRE_REG_PROV_SRV,
            that,
            aDataCorreo = {EnvioCorreosMasivoDetSet: []}

        //let sGRP_PROV_SOLICITUD_FACTURA = 'f5ac553c-8b9f-4678-acb9-a6e7cf4f4f3b'  //QAS
        let sGRP_PROV_SOLICITUD_FACTURA = 'fab86486-8e06-45e4-b762-d182bc2c3c2c' //PRD
        return BaseController.extend("ns.cosapi.cargamasivaproveedor.controller.Home", {
            onInit: function () {
                that = this
                this.setModel( new JSONModel([]), "detalleExcel" )
                this.setModel ( new JSONModel(), "listaFunciones" )
                oModelExcel = this.getModel("detalleExcel")
                oModelListaFunciones = this.getModel("listaFunciones")

                ZMMGS_PRE_REG_PROV_SRV = this.getOwnerComponent().getModel("ZMMGS_PRE_REG_PROV_SRV");

                this.onListaPaises();
                this.onListaTipoDocumento();
            },
            setDataTable: async function (data) {

                if (data.length > 0) {
                    let oCamposValidados = await this.validarCamposExcel(data)
                    oModelExcel.setData(oCamposValidados)
                    sap.ui.core.BusyIndicator.hide()
                } else {
                    MessageBox.error("No existe datos en la plantilla.")
                    sap.ui.core.BusyIndicator.hide()
                }
            },

            onGuardarExcel: async function () {
                async function delay(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let aDataExcelOld = oModelExcel.getData()
                let aMensajes = []
                
                if (aDataExcelOld.length == 0) {
                    MessageBox.error("Por favor, subir un archivo excel.")
                    return
                }

                let aDataExcel = aDataExcelOld.filter( oPos => oPos.Estado === true )
                if (!aDataExcel.length) {
                    MessageBox.error("Debe haber al menos 1 proveedor válido.")
                    return
                }
                
                sap.ui.core.BusyIndicator.show(0)
                //Primero se envian los correos de SAP
                let oResultCorreo = await that._enviarCorreosSAP()
                if (oResultCorreo.Codigo != "200") {
                    MessageBox.error(oResultCorreo.Mensaje)
                    sap.ui.core.BusyIndicator.hide(0)
                    return
                }

                for ( let i = 0; i < aDataExcel.length; i++ ) {

                    let oDataExcel = aDataExcel[i]

                    // //Obtenemos el código BP
                    // let sFindCodBP = await that._obtenerCodigoBP(oDataExcel)
                    // if (!sFindCodBP) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: "No existe ningun codigo Business Partner para el RUC " + oDataExcel.Taxnumxl,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }

                    // //Guardamos el proveedor al pre registro
                    // let oGuardarPreRegistro = await that.guardarPreRegistro(formatoJsonPreRegistro(oDataExcel))
                    // await delay(1000);
                    // if ( oGuardarPreRegistro.Codigo == "500" ) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: oGuardarPreRegistro.Mensaje,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }

                    // //Aprobamos el pre registro
                    // let oApprovePreRegistro = await that._approveSolicitudes(oDataExcel, "02")
                    // await delay(1000);
                    // if (oApprovePreRegistro.Codigo == "500" ) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: oApprovePreRegistro.Mensaje,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }

                    // //Enviamos la solicitud del proveedor
                    // let oSendSolicitud = await that._approveSolicitudes(oDataExcel, "04")
                    // await delay(1000);
                    // if (oSendSolicitud.Codigo == "500" ) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: oSendSolicitud.Mensaje,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }

                    // //Enviamos la solicitud del proveedor
                    // let oApproveActualiacion = await that._approveSolicitudes(oDataExcel, "05")
                    // await delay(1000);
                    // if (oApproveActualiacion.Codigo == "500" ) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: oApproveActualiacion.Mensaje,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }
                    
                    //Creamos el proveedor en la plataforma proveedores IAS
                    let oValidate = await that.createUserBtp(formatoJsonCreateIAS(oDataExcel));
                    if (!oValidate.success) {
                        aMensajes.push({
                            Taxnumxl: oDataExcel.Taxnumxl,
                            Mensaje: oValidate.mensaje,
                            Estado: false,
                        })
                        sap.ui.core.BusyIndicator.hide()
                        continue;
                    } 

                    //Actualizamos los grupos del proveedor
                    //let sId = await that._getIdUserIas(oDataExcel)
                    let bValidateGroupUser = await that.updateGroupsUser(oValidate.id)

                    if (!bValidateGroupUser) {
                        aMensajes.push({
                            Taxnumxl: oDataExcel.Taxnumxl,
                            Mensaje: "Hubo un error al actualizar los roles del proveedor.",
                            Estado: false,
                        })
                        sap.ui.core.BusyIndicator.hide()
                        continue;
                    }

                    // //Actualizamos la tabla SAP con el nuevo codigo BP
                    // let oResultBPSap = await that._addBpTableSAP(sFindCodBP, oDataExcel)
                    // await delay(1000);
                    // if (oResultBPSap.Codigo == "500" ) {
                    //     aMensajes.push({
                    //         Taxnumxl: oDataExcel.Taxnumxl,
                    //         Mensaje: oResultBPSap.Mensaje,
                    //         Estado: false,
                    //     })
                    //     sap.ui.core.BusyIndicator.hide()
                    //     continue;
                    // }

                    aMensajes.push({
                        Taxnumxl: oDataExcel.Taxnumxl,
                        Mensaje: "Los datos se guardaron con éxito.",
                        Estado: true,
                    })
                }
                
                sap.ui.core.BusyIndicator.hide()
                that._mostrarMensajes(aMensajes);
                oModelExcel.setData([])

                function formatoJsonPreRegistro (oData) {
                    return {
                        "Land1" : oData.Land1,
                        "Taxnumxl" : oData.Taxnumxl,
                        "Stcdt" : oData.Stcdt.substring(0,4),
                        "Name1" : oData.Name1,
                        "Name2" : oData.Name2,
                        "Name3" : oData.Name3,
                        "Name4" : oData.Name4,
                        "Representante" : oData.Representante.substring(0,10),
                        "Identificacion" : oData.Identificacion.substring(0,10),
                        "Telefono" : oData.Telefono.substring(0,10),
                        "Correo" : oData.Correo.substring(0,10),
                        "Codigoestado" : oData.Codigoestado,
                        "Usuario" : oData.Usuario,
                        "Correonombre" : oData.Correonombre,
                        "Direccion" : "", //oData.Direccion.substring(0, 35),
                        "FechaInAct" : ""
                    }
                }

                function formatoJsonCreateIAS (oData) {
                    return {
                        "Taxnumxl": oData.Taxnumxl,
                        "Fullname": oData.Fullname,
                        "Correo": oData.Correo,
                        "Telefono": oData.Telefono
                    }
                }
            },

            _mostrarMensajes: function (aMensajes) {
                let oModel = new sap.ui.model.json.JSONModel();
                oModel.setData({ Mensajes: aMensajes });

                var oList = new sap.m.List({
                    items: {
                        path: '/Mensajes',
                        template: new sap.m.StandardListItem({
                            title: '{Taxnumxl}',
                            description: '{Mensaje}',
                            icon: {
                                path: 'Estado',
                                formatter: function(estado) {
                                    return estado ? 'sap-icon://message-success' : 'sap-icon://message-error';
                                }
                            },
                            highlight: {
                                path: 'Estado',
                                formatter: function(estado) {
                                    return estado ? 'Success' : 'Error';
                                }
                            },
                            wrapping: true
                        })
                    }
                });
                
                oList.setModel(oModel);

                var oDialog = new sap.m.Dialog({
                    title: 'Lista de Mensajes',
                    contentWidth: '30%',
                    contentHeight: '350px',
                    content: oList,
                    beginButton: new sap.m.Button({
                        text: 'Cerrar',
                        press: function () {
                            oDialog.close();
                        }
                    })
                });
                
                oDialog.open();
            },

            guardarPreRegistro: function (oData) {
                return new Promise(async (resolve,reject) => {
                    try {
                        const oCrearPreregistro = await this.createEntity(ZMMGS_PRE_REG_PROV_SRV, "/PreRegistroSet", oData);
                        resolve(oCrearPreregistro)                        
                    } catch (error) {
                        resolve(false)
                    }
                });
            },

            createUserBtp: function (oUser) {
                let usuario = {
                    "externalId": oUser.Taxnumxl,
					"schemas": [
					   "urn:ietf:params:scim:schemas:core:2.0:User",
					   "urn:ietf:params:scim:schemas:extension:sap:2.0:User",
					   "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
					],
					"userName": oUser.Taxnumxl,
					"password": "CosapiUser01!*",
					"name": {
					   "familyName": oUser.Taxnumxl,
					   "givenName": oUser.Fullname,
					   "formatted": oUser.Taxnumxl
					},
					"displayName": oUser.Fullname,
					"nickName": oUser.Taxnumxl,
					"userType": "Employee",
					"preferredLanguage": "Spanish",
					"locale": "ES",
					"active": true,
					"emails": [
					   {
						  "type": "work",
						  "value": oUser.Correo,
						  "primary": true
					   }
					],
					"phoneNumbers": [
					   {
						  "type": "work",
						  "value": oUser.Telefono,
						  "primary": true
					   }
					],
					"urn:ietf:params:scim:schemas:extension:sap:2.0:User": {
					   "sendMail": false,
					   "mailVerified": true,
					   "status": "active",
					   "contactPreferences": {
						  "email": "yes",
						  "telephone": "yes"
					   },
					   "emails": [
						  {
							 "type": "work",
							 "value": oUser.Correo,
							 "primary": true,
							 "verified": true
						  }
					   ],
					   "phoneNumbers": [
						  {
							 "type": "work",
							 "value": oUser.Telefono,
							 "primary": true
						  }
					   ]
					}
				};
				usuario = JSON.stringify(usuario);
				let oResult = {
					success: false,
					mensaje: "",
                    id: ""
				};
				// Creacion de usuario.
                let sUrl = that.getBaseURL() + "/scim/Users";
				return new Promise(function (resolve, reject) {
					$.ajax({
						type: "POST",
						data: usuario,
						async: false,
						url: sUrl,
						contentType: "application/scim+json",
						success: async function (data, textStatus, xhr) {
                            console.log(data);
							if (textStatus == "success") {
                                oResult.success = true;
                                oResult.id = data.id
                                resolve(oResult)
								// let oData = {
								// 	"schemas": [
								// 		"urn:ietf:params:scim:api:messages:2.0:PatchOp"
								// 	],
								// 	"Operations": [
								// 	{
								// 		"op": "add",
								// 		"path": "members",
								// 		"value": [
								// 			{
								// 				"value": data.id
								// 			}
								// 		]
								// 	}
								// 	]
								// }
								// $.ajax({
								// 	type: "PATCH",
								// 	data: JSON.stringify(oData),
								// 	async: false,
								// 	url: that.getBaseURL() + "/scim/Groups/bf8c3fcf-ce0e-4e5f-a772-427f97d992cb",
								// 	contentType: "application/scim+json",
								// 	success: async function (data, textStatus, xhr) {
								// 		oResult.success = true;
								// 		resolve(oResult)
								// 	},
								// 	error: function (error) {
								// 		console.log(error);
								// 		oResult.success = false;
								// 		resolve(oResult)
								// 	}
								// });
							} else {
								oResult.success = false;
								resolve(oResult)
							}
							
						},
						error: function (error) {
							console.log(error);
							oResult.success = false;
							if ( error.responseText.indexOf("exists") >= 0 && error.responseText.indexOf("email") >= 0 ) {
								oResult.mensaje = "El correo electrónico del proveedor ya existe. Por favor, comunicarse con administración."
							} else if ( error.responseText.indexOf("exists") >= 0 && error.responseText.indexOf("name") >= 0 ) {
								oResult.mensaje = "El Nif del proveedor ya existe. Por favor, comunicarse con administración."
							} else {
								oResult.mensaje = error.responseText;
							}
                            resolve(oResult)
						}

					});
				});
            },

            //Se aprueba la solicitud actualización de datos
            _approveSolicitudes: async function (oPreRegistro, sCodEstado) {
                return new Promise(async (resolve,reject) => {
                    let oSendData = { 
                        "Taxnumxl": oPreRegistro.Taxnumxl,
                        "Codigoestado": sCodEstado,
                        "Usuario": "",
                        "Correonombre": ""
                    }
                    try {
                        const oResultData = await this.createEntity(ZMMGS_PRE_REG_PROV_SRV, "/LogPPSet", oSendData)
                        resolve(oResultData)
                    } catch (error) {
                        resolve(false)
                    }
                });
            },

            //Obtenemos el código BP con el RUC
            _obtenerCodigoBP: async function (oPreRegistro) {
                return new Promise(async (resolve,reject) => {
                    let API_BUSINESS_PARTNER =  this.getOwnerComponent().getModel("API_BUSINESS_PARTNER");
                    let filters = []
                    
                    filters.push(new Filter("SearchTerm1", "EQ", `${oPreRegistro.Taxnumxl}`))
                    try {
                        const oResultData = await this.readEntity(API_BUSINESS_PARTNER, "/A_BusinessPartner", {filters})
                        if (oResultData.results.length > 0) {
                            resolve(oResultData.results[0].BusinessPartner)
                        } else {
                            resolve(false)
                        }
                    } catch (error) {
                        resolve(false)
                    }
                });
            },

            _getIdUserIas: function (oPreRegistro) {
                return new Promise(function (resolve, reject) {      
                    $.ajax({
                        type: "GET",
                        async: false,
                        url: that.getBaseURL() + "/scim/Users?filter=userName eq '" + oPreRegistro.Taxnumxl + "'",
                        contentType: "application/scim+json",
                        success: async function (data, textStatus, xhr) {
                            resolve(data.Resources[0].id)
                        },
                        error: function (error) {
                            console.log(error)
                            resolve(false)
                        }
                    });
                });
                
            },
              
            updateGroupsUser: function (sId) {
                return new Promise(function (resolve, reject) {
                    let oData = {
                        "schemas": [
                            "urn:ietf:params:scim:api:messages:2.0:PatchOp"
                        ],
                        "Operations": [
                            {
                                "op": "add",
                                "path": "members",
                                "value": [
                                    {
                                        "value": sId
                                    }
                                ]
                            }
                        ]
                    }
                    $.ajax({
                        type: "PATCH",
                        data: JSON.stringify(oData),
                        async: false,
                        url: that.getBaseURL() + "/scim/Groups/" + sGRP_PROV_SOLICITUD_FACTURA,
                        contentType: "application/scim+json",
                        success: async function (data, textStatus, xhr) {
                            resolve(true)
                        },
                        error: function (error) {
                            resolve(false)
                        }
                    });
                });
            },
              
              //Agregar el codigo BP a la tabla Z
            _addBpTableSAP: async function (sBP, oPreRegistro) {
                return new Promise(async (resolve,reject) => {
                    let oSendData = { 
                        "Taxnumxl": oPreRegistro.Taxnumxl,
                        "Numerodebp": sBP
                    }
                    try {
                        const oResultData = await this.createEntity(ZMMGS_PRE_REG_PROV_SRV, "/RegistroNumeroBPSet", oSendData)
                        resolve(oResultData)
                    } catch (error) {
                        resolve(false)
                    }
                });
            },

            //Funcion para enviar correos SAP
            _enviarCorreosSAP: function () {
                return new Promise(async (resolve,reject) => {
                    try {
                        const oCrearPreregistro = await this.createEntity(ZMMGS_PRE_REG_PROV_SRV, "/EnvioCorreosMasivoCabSet", aDataCorreo);
                        resolve(oCrearPreregistro)                        
                    } catch (error) {
                        resolve(false)
                    }
                });
            },

            validarCamposExcel: async function (data) {
                let aReturn = []
                let promises = []

                for (let i = 0; i < data.length; i++) {
                    let sMensaje = ""
                    let oData = data[i]
                    let oReturn = {
                        "Name1" : "",
                        "Name2" : "",
                        "Name3" : "",
                        "Name4" : "",
                        "Codigoestado" : "01",
                        "Usuario" : "",
                        "Correonombre" : "",
                        "Direccion" : "Sin direccion",
                        "FechaInAct" : "12-12-2022",
                        "RazonSocial": "",
                        "Estado": true,
                        "Mensaje": sMensaje
                    }

                    if (!oData.PAIS || oData.PAIS.trim() == "") {
                        sMensaje += "• Falta completar el campo País. \n"
                        oReturn.Estado = false
                    } else {
                        let oEncontrar = oModelListaFunciones.getProperty("/Paises").find( oPos => oPos.Land1 == oData.PAIS.trim() )
                        if (!oEncontrar) {
                            sMensaje += "• No existe un país con el código " + oData.PAIS.trim() + " del campo País. \n"
                            oReturn.Estado = false
                        }
                        oReturn.Land1 = oData.PAIS.trim()
                    }

                    if (!oData.NIF || oData.NIF.toString().trim() == "") {
                        sMensaje += "• Falta completar el campo NIF. \n"
                        oReturn.Estado = false
                    } else {
                        let sNif = oData.NIF.toString().trim()
                        let bValidateNif = await this._validarExisteEmailOrNif(sNif, "userName")

                        if (bValidateNif) {
                            sMensaje += "• Ya existe un usuario con el Nif " + sNif + ". \n"
                            oReturn.Estado = false
                        }
                        oReturn.Taxnumxl = oData.NIF.toString().trim()
                        oReturn.Usuario = oData.NIF.toString().trim()
                    }

                    if (!oData.TIPO_DOCUMENTO || oData.TIPO_DOCUMENTO.toString().trim() == "") {
                        sMensaje += "• Falta completar el campo Tipo de Documento. \n"
                        oReturn.Estado = false
                    } else {
                        let sTipoDoc =  oData.TIPO_DOCUMENTO.toString().trim()
                        let oEncontrar = oModelListaFunciones.getProperty("/TiposDocumento").find( oPos => oPos.Tipodocumento == sTipoDoc )
                        if (!oEncontrar) {
                            sMensaje += "• No existe un tipo de documento con el código " + sTipoDoc + " del campo Tipo de Documento. \n"
                            oReturn.Estado = false
                        } else {
                            if (oReturn.Taxnumxl) {
                                let sNif = oReturn.Taxnumxl,
                                    oValidateDocument
                                
                                if (sTipoDoc == "96" || sTipoDoc == "6") {
                                    if (sTipoDoc == "96") { // DNI
                                        oValidateDocument = await this.validarDNI(sNif);
                                    } else if (sTipoDoc == "6") { // RUC
                                        oValidateDocument = await this.validarRuc(sNif);
                                    }

                                    if (oValidateDocument.type == "E") {
                                        sMensaje += "• " + oValidateDocument.message.toUpperCase();
                                        oReturn.Estado = false;
                                    } else {
                                        if (oValidateDocument.data.condicion == "HABIDO" && oValidateDocument.data.estado == "ACTIVO") {
                                            let sRazonSocial = oValidateDocument.data.razonSocial
                                            oReturn.RazonSocial = sRazonSocial
                                            oReturn.Direccion = oValidateDocument.data.direccion
                                            let aPartes = separarStringEnPartes(sRazonSocial,40);
                                            for (let x = 0; x < aPartes.length; x++) {
                                                if( x==0 ){
                                                    oReturn.Name1 = aPartes[0];
                                                }
                                                if( x==1 ){
                                                    oReturn.Name2 = aPartes[1];
                                                }
                                                if( x==2 ){
                                                    oReturn.Name3 = aPartes[2];
                                                }
                                                if( x==3 ){
                                                    oReturn.Name4 = aPartes[3];
                                                }
                                            }
                                        } else {
                                            sMensaje = "• " + oValidateDocument.data.condicion;
                                            oReturn.Estado = false;
                                        }
                                    }
                                } else {
                                    if (!oData.RAZON_SOCIAL || oData.RAZON_SOCIAL.toString().trim() == "") {
                                        sMensaje += "• Falta completar el campo Razón Social. \n"
                                        oReturn.Estado = false
                                    } else {
                                        oReturn.RazonSocial = oData.RAZON_SOCIAL.toString().trim()
                                        let aPartes = separarStringEnPartes(oReturn.RazonSocial,40);
                                        for (let x = 0; x < aPartes.length; x++) {
                                            if( x==0 ){
                                                oReturn.Name1 = aPartes[0];
                                            }
                                            if( x==1 ){
                                                oReturn.Name2 = aPartes[1];
                                            }
                                            if( x==2 ){
                                                oReturn.Name3 = aPartes[2];
                                            }
                                            if( x==3 ){
                                                oReturn.Name4 = aPartes[3];
                                            }
                                        }
                                    }
                                    
                                }
                                
                            }
                            
                        }
                        oReturn.Stcdt = sTipoDoc
                    }

                    if (!oData.REPRESENTANTE_LEGAL || String(oData.REPRESENTANTE_LEGAL).trim() == "") {
                        sMensaje += "• Falta completar el campo Representante Legal. \n"
                        oReturn.Estado = false
                    } else {
                        oReturn.Representante = String(oData.REPRESENTANTE_LEGAL).trim()
                    }

                    if (!oData.IDENTIFICACION || oData.IDENTIFICACION.toString().trim() == "") {
                        sMensaje += "• Falta completar el campo Identificación. \n"
                        oReturn.Estado = false
                    } else {
                        oReturn.Identificacion = oData.IDENTIFICACION.toString().trim()
                    }

                    if (!oData.TELEFONO || oData.TELEFONO.toString().trim()== "") {
                        sMensaje += "• Falta completar el campo Teléfono. \n"
                        oReturn.Estado = false
                    } else {
                        oReturn.Telefono = oData.TELEFONO.toString().trim()
                    }

                    if (!oData.CORREO_CORPORATIVO || oData.CORREO_CORPORATIVO.trim() == "") {
                        sMensaje += "• Falta completar el Correo Corporativo. \n"
                        oReturn.Estado = false
                    } else {
                        let sCorreo = oData.CORREO_CORPORATIVO.trim()
                        let bValidate = validarCorreoElectronico(sCorreo)

                        if (!bValidate) {
                            sMensaje += "• Por favor, ingresar un correo electrónico válido en el campo Correo Corporativo. \n"
                            oReturn.Estado = false
                        } else {
                            let bValidateCorreo = await this._validarExisteEmailOrNif(sCorreo, "emails.value")

                            if (bValidateCorreo) {
                                sMensaje += "• El correo corporativo ya existe. Por favor, ingresar otro. \n"
                                oReturn.Estado = false
                            }
                        }

                        oReturn.Correo = sCorreo
                        oReturn.Correonombre = sCorreo;
                    }

                    oReturn.Mensaje = sMensaje
                    aReturn.push(oReturn)
                    
                    //Se cargan los datos en el array del CORREO
                    if (oReturn.Estado) {
                        aDataCorreo.EnvioCorreosMasivoDetSet.push({
                            "Taxnumxl"          : oReturn.Taxnumxl,
                            "Nombrecompleto"    : oReturn.RazonSocial,
                            "Correo"            : oReturn.Correo
                        })
                    }
                }

                return aReturn

                function validarCorreoElectronico(correo) {
                    // Expresión regular para validar correo electrónico
                    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    return regexCorreo.test(correo);
                }

                function separarStringEnPartes (str, tamano) {
                    var partes = [];
                    for (var i = 0; i < str.length; i += tamano) {
                        partes.push(str.substring(i, i + tamano));
                    }
                    return partes;
                }
            },

            onVerMotivo: function(oEvent){
                let oProveedor = oEvent.getSource().getBindingContext("detalleExcel").getObject()
                MessageBox.error(oProveedor.Mensaje)
            },

            onCargarArchivo: async function (event) {
                const file = event.getParameter("files") && event.getParameter("files")[0];
                const fileUploader = event.getSource();
                sap.ui.core.BusyIndicator.show(0);
                const data = await this._import(file);
    
                if (data && data.length > 0) {
                    this.setDataTable(data);
                } else {
                    MessageBox.information("El archivo no contiene información")
                    sap.ui.core.BusyIndicator.hide();
                }
                fileUploader.clear();
            },

            _import: async function (file) {
                var excelData = {};
                const resolveImport = (e) => {
                    var data = e.target.result;
                    var workbook = XLSX.read(data, {
                        type: 'binary'
                    });
                    workbook.SheetNames.forEach(function (sheetName) {
                        if (sheetName === "Proveedor") {
                            excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                        }
                    });

                    let keys = [], keysNoValidas = [];
                    if (excelData.length > 0) {
                        return excelData
                    }
                };
                const rejectImport = (error) => {
                    console.log(error);
                }
                const readerImport = new Promise((resolve, reject) => {
                    if (file && window.FileReader) {
                        var reader = new FileReader();
                        reader.onload = resolve;
                        reader.onerror = reject;
                        reader.readAsBinaryString(file);
                    }
    
                });
    
                return await readerImport.then(resolveImport, rejectImport);
            },

            onDescargarPlantilla: function () {
                let wbPlantilla = XLSX.utils.book_new();

                let oProveedor = [
                    {
                        "PAIS"                  : "",
                        "TIPO_DOCUMENTO"        : "",
                        "NIF"                   : "",
                        "RAZON_SOCIAL"          : "",
                        "REPRESENTANTE_LEGAL"   : "",
                        "IDENTIFICACION"        : "",
                        "CORREO_CORPORATIVO"    : "",
                        "TELEFONO"              : ""

                    }
                ]
                let wsPlantillaProveedor = XLSX.utils.json_to_sheet(oProveedor)
                XLSX.utils.book_append_sheet(wbPlantilla, wsPlantillaProveedor, "Proveedor")
                
                let oPaises = [
                    {"CODIGO": "PE", "PAIS": "PERU"},
                    {"CODIGO": "CL", "PAIS": "CHILE"}
                ]
                let wsPlantillaPais = XLSX.utils.json_to_sheet(oPaises)
                XLSX.utils.book_append_sheet(wbPlantilla, wsPlantillaPais, "Países");
                
                let oTipoDoc = [
                    {"CODIGO": "PE2", "PAIS": "DNI"},
                    {"CODIGO": "PE1", "PAIS": "RUC"}
                ]
                let wsPlantillaTipoDoc = XLSX.utils.json_to_sheet(oTipoDoc)
                XLSX.utils.book_append_sheet(wbPlantilla, wsPlantillaTipoDoc, "Tipo de Documento");

                XLSX.writeFile(wbPlantilla, "Plantilla Pre-registro Proveedor.xlsx");
            },

            //Funciones para los filtros de campos select
            onListaPaises: async function(){
                try {
                    const listaPaises = await this.readEntity(ZMMGS_PRE_REG_PROV_SRV, "/ConsultaPaisesSet", {});
                    oModelListaFunciones.setProperty("/Paises", listaPaises.results)
                } catch (error) {
                    MessageBox.error(error)
                }
            },
            onListaTipoDocumento:async function(){
                try {
                    const listaTiposDocumento = await this.readEntity(ZMMGS_PRE_REG_PROV_SRV, "/ConsultaTipoDocumentoSet", {});
                    oModelListaFunciones.setProperty("/TiposDocumento", listaTiposDocumento.results)
                } catch (error) {
                    MessageBox.error(error)                    
                }
            },

            //Funciones de validación del NIF
            validarRuc: async function (sRuc) {
                return new Promise(async (resolve,reject) => {
                    // Datos
                    let token = 'apis-token-7995.8AnfWmuPPQZwDqqbabyPvjn9ykTmYLDO'
                    let ruc = sRuc
                    let oReturn = {
                        type: 'S',
                        message: '',
                        data: null
                    }
                    
                    let xhr = new XMLHttpRequest();
                    
                    xhr.open('GET', this.getBaseURL() + '/v2/sunat/ruc?numero=' + ruc);
                    
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                    
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            
                            let response = JSON.parse(xhr.responseText)
                            oReturn.data = response
                            resolve(oReturn);
                        } else {
                            
                            oReturn.type = "E"
                            oReturn.message = JSON.parse(xhr.responseText).message
                            resolve(oReturn);
                        }
                    };
                    
                    xhr.onerror = function() {
                        console.error('Error de red al intentar acceder a la API');
                    };
                    
                    xhr.send();
                });
            },

            validarDNI: async function (sDni) {
                return new Promise(async (resolve,reject) => {
                    var token = 'apis-token-7995.8AnfWmuPPQZwDqqbabyPvjn9ykTmYLDO'
                    var dni = sDni
                    let oReturn = {
                        type: 'S',
                        message: '',
                    }
                    
                    var xhr = new XMLHttpRequest();
                    
                    xhr.open('GET', this.getBaseURL() + '/v2/reniec/dni?numero=' + dni);
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);

                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            var response = JSON.parse(xhr.responseText);
                            resolve(oReturn);
                            console.log(response);
                        } else {
                            console.error('Error al obtener los datos de la API');
                            oReturn.type = "E"
                            oReturn.message = JSON.parse(xhr.responseText).message
                            resolve(oReturn)
                        }
                    };
                    xhr.onerror = function() {
                        console.error('Error de red al intentar acceder a la API');
                    };
                    xhr.send();
                });
                
            }
        });
    });
