sap.ui.define([
	"nscosapi/contabilizarfacturas/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
