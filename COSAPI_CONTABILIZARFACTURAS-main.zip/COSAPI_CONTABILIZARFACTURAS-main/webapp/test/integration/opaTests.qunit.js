/* global QUnit */

sap.ui.require(["ns/cosapi/contabilizarfacturas/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
