sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ns.cosapi.contabilizarfacturas.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  