sap.ui.define([],
    function () {
        "use strict";

        return {
            formatVisible:function(visible){
                if(visible)
                    return true;
                return false;
            }

            
        };

    });