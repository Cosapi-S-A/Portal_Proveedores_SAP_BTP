/* global QUnit */

sap.ui.require(["ns/cosapi/aprobacionsolppro/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
