sap.ui.define([
	"nscosapi/aprobacionsolppro/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
