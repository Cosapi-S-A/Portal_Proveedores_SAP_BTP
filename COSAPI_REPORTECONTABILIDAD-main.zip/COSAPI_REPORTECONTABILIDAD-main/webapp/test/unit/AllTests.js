sap.ui.define([
	"nscosapi/reportecontabilidad/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
