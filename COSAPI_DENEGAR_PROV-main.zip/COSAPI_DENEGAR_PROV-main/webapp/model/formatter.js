sap.ui.define([],
    function () {
        "use strict";

        return {

            
            /**
             * 
             * @param {*} sText 
             * @returns 
             */
            getKeyTipoProv: function (sText) {
                let sReturn = ""
                switch (sText) {
                    case "Bienes":
                        sReturn = "TpProvBienes"
                        break
                    case "Servicios":
                        sReturn = "TpProvServicios"
                        break
                    case "Subcontratista":
                        sReturn = "TpProvSubcontratista"
                        break
                }
                return sReturn
            },

            /**
             * 
             * @param {*} table 
             * @param {*} bundle 
             * @returns [{
                    key: "nif_col",
                    label: bundle.getText("nro"),
                    path: "Taxnumxl"
                },
                {
                    key: "razonsocial_col",
                    label: bundle.getText("razonsocial"),
                    path: "Fullname"
                }]
             */
            _getDataHelper: function (table, bundle) {
                const columns = table.getColumns();
                const arreglo = [];
                for (let i = 0; i < columns.length; i++) {
                    const col = columns[i];
                    const pathLabel = col.getAggregation('header').getBindingInfo('text').parts[0].path;
                    arreglo.push({
                        key: pathLabel + "_col",
                        label: bundle.getText(pathLabel),
                        path: pathLabel,
                        size: "1.75",
                    });

                }
                return arreglo;
            },

            /**
             * 
             * @param {*} table 
             * {
                    label: 'Text',
                    type: EdmType.String,
                    property: 'Taxnumxl',
                    width: 20,
                    wrap: true
                }
             */
            _getDataExcel: function (table, EdmType) {
                const columns = table.getColumns();
                const arreglo = [];
                for (let i = 0; i < columns.length - 1; i++) {
                    const col = columns[i];
                    const pathLabel = col.getAggregation('header').getBindingInfo('text').parts[0].path;
                    arreglo.push({
                        label: pathLabel,
                        type: EdmType.String,
                        property: pathLabel,
                        wrap: true
                    });
                }
                return arreglo;
            },

            formatoNombreArchivo: function (sFile) {
                var textoCodificado = encodeURIComponent(sFile);
                var sNombre = decodeURIComponent(textoCodificado);
                var reemplazos = {
                    'Ã': 'A', 'À': 'A', 'Á': 'A', 'Ä': 'A', 'Â': 'A',
                    'È': 'E', 'É': 'E', 'Ë': 'E', 'Ê': 'E',
                    'Ì': 'I', 'Í': 'I', 'Ï': 'I', 'Î': 'I',
                    'Ò': 'O', 'Ó': 'O', 'Ö': 'O', 'Ô': 'O',
                    'Ù': 'U', 'Ú': 'U', 'Ü': 'U', 'Û': 'U',
                    'ã': 'a', 'à': 'a', 'á': 'a', 'ä': 'a', 'â': 'a',
                    'è': 'e', 'é': 'e', 'ë': 'e', 'ê': 'e',
                    'ì': 'i', 'í': 'i', 'ï': 'i', 'î': 'i',
                    'ò': 'o', 'ó': 'o', 'ö': 'o', 'ô': 'o',
                    'ù': 'u', 'ú': 'u', 'ü': 'u', 'û': 'u',
                    'Ñ': 'N', 'ñ': 'n',
                    'Ç': 'c', 'ç': 'c'
                };
                var textoNormalizado = sNombre.replace(/[ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç]/g, function (match) {
                    return reemplazos[match];
                });
                return textoNormalizado;
            },

            getRequestOptionFolder: function (nameFolder) {
                const myHeaders = new Headers();
                const formdata = new FormData();
                formdata.append("cmisaction", "createFolder");
                formdata.append("propertyId[0]", "cmis:name");
                formdata.append("propertyValue[0]", nameFolder);
                formdata.append("propertyId[1]", "cmis:objectTypeId");
                formdata.append("propertyValue[1]", "cmis:folder");
                formdata.append("succinct", "true");
                const requestOptions = {
                    method: 'POST',
                    headers: myHeaders,
                    body: formdata,
                    "mimeType": "multipart/form-data",
                };
                return requestOptions;
            },

            getRequestOptionFile: function (sName, file) {
                const myHeaders = new Headers();
                const formdata = new FormData();
                formdata.append("cmisaction", "createDocument");
                formdata.append("propertyId[0]", "cmis:name");
                formdata.append("propertyValue[0]", sName);
                formdata.append("propertyId[1]", "cmis:objectTypeId");
                formdata.append("propertyValue[1]", "cmis:document");
                formdata.append("filename", sName);
                formdata.append("_charset", "UTF-8");
                formdata.append("includeAllowableActions", "False");
                formdata.append("succinct", "true");
                formdata.append("file", file.File, {
                    filename: sName,
                    contentType: file.type,
                });
                const requestOptions = {
                    method: 'POST',
                    headers: myHeaders,
                    body: formdata,
                    redirect: 'follow'
                };
                return requestOptions;
            },

            getRequestDelete:function(objectId){
                const myHeaders = new Headers();
                const formdata = new FormData();
                formdata.append("cmisaction", "delete");
                formdata.append("objectId", objectId);
                formdata.append("allVersions", "true");
                const requestOptions = {
                    method: 'POST',
                    headers: myHeaders,
                    body: formdata,
                };
                return requestOptions;
            }
        };

    });