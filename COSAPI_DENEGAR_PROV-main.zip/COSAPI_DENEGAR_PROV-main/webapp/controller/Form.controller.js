sap.ui.define([
    "./BaseController",
    "./../model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/library",
    "sap/m/MessageBox"
],
    function (BaseController, formatter, JSONModel, coreLibrary, MessageBox) {
        "use strict";

        return BaseController.extend("ns.cosapi.denegarproveedor.controller.Form", {
            messages: [],
            onInit: function () {
                const bundle = this.getResourceBundle();
                try {
                    const model = new JSONModel({
                        messages: [],
                        load: {
                            message: bundle.getText("loadmsg")
                        },
                        form: null
                    });
                    this.setModel(model, "model");
                    this.getRouter().getRoute("RouteForm").attachPatternMatched(this._onObjectMatched, this)
                } catch (error) {
                    const message = error;
                    MessageBox.error(message, {
                        actions: [MessageBox.Action.CLOSE],
                        onClose: function () {
                            this.onCancel();
                        },
                        dependentOn: this.getView()
                    });
                }
            },

            _onObjectMatched: async function (event) {
                this.showBusyText();
                const arg = event.getParameter("arguments");
                const model = this.getModel('model');
                const inputNroIdentificacion = this.byId('inputNroIdentificacion'),
                    inputRazonSocial = this.byId('inputRazonSocial'),
                    fileUpload = this.byId('fileUpload');
                inputNroIdentificacion.setValueState('None');
                inputRazonSocial.setValueState('None');
                fileUpload.setValueState('None');
                fileUpload.setValue(null);
                let proveedor = {
                    NroIdentificacion: null,
                    RazonSocial: null,
                    LinkFuente: "",
                    MotivoInhabilitacion: "",
                    RegistradoPor: await this.getInfoUser()
                };

                if (arg) {
                    const nroIden = arg.NroIdentificacion;
                    if (nroIden !== "0") {
                        proveedor = await this._getProveedor(nroIden);

                        //proveedor.file = await this._sendFetch();
                    }
                }
                model.setProperty("/form", proveedor);
                this.hideBusyText();
            },

            _getProveedor: async function (nroIden) {
                const modelRegProveepCrud = this.getOwnerComponent().getModel();
                const proveedor = await this.readEntity(modelRegProveepCrud, `/ProveedoresDenegadosSet(NroIdentificacion='${nroIden}')`, {});
                if (proveedor) proveedor.edit = true;
                return proveedor;
            },

            onSave: async function () {
                const t = this;
                const bundle = this.getResourceBundle();
                let callback = null;
                try {
                    const model = this.getModel('model');
                    const proveedor = model.getProperty('/form');
                    this.getValidateProveedor(proveedor);
                    if (this.messages.length === 0) {
                        model.setProperty("/load/message", bundle.getText('loadmsgUpload'));
                        this.showBusyText();
                        const modelRegProveepCrud = this.getOwnerComponent().getModel();
                        let sPathProveedor = '/ProveedoresDenegadosSet';
                        let envio = null;
                        const uploadFile = await this._saveFileDocument(proveedor.NroIdentificacion);
                        if (uploadFile) {
                            model.setProperty("/load/message", bundle.getText('loadmsgCreate'));
                            const fileId = uploadFile.succinctProperties['cmis:objectId'];
                            t.messages.push({
                                title: bundle.getText("documento"),
                                type: coreLibrary.MessageType.Success,
                                subtitle: bundle.getText("createsuccess")
                            });
                            callback = t.onNavBack;
                            proveedor.IdObjectDms = fileId;
                            let delteFile = false;
                            if (proveedor.edit) {
                                sPathProveedor += `(${proveedor.NroIdentificacion})`;
                                delete proveedor.edit;
                                envio = await this.updateEntity(modelRegProveepCrud, sPathProveedor, proveedor);
                            } else
                                envio = await this.createEntity(modelRegProveepCrud, sPathProveedor, proveedor);

                            if (envio) {
                                const mensajeodata = envio.Mensaje;
                                if (envio.Codigo === "200") {
                                    t.messages.push({
                                        title: bundle.getText("createSAP"),
                                        type: coreLibrary.MessageType.Success,
                                        subtitle: mensajeodata
                                    })
                                } else
                                    delteFile = true;

                            } else
                                delteFile = true;
                            if (delteFile) {
                                const requestDeleteFile = formatter.getRequestDelete(fileId);
                                await this._sendFetchDelete(urlWithParams, requestDeleteFile);
                            }
                        }
                    }
                } catch (error) {
                    t.validateErrorList(t, error, "ProveedoresDenegadosSet");
                }
                this.hideBusyText();
                this._getPopUpMensaje(null, null, callback, t);

            },

            onCancel: function () {
                this.onNavBack();
            },

            getValidateProveedor: function (proveedor) {
                const bundle = this.getResourceBundle();
                const inputNroIdentificacion = this.byId('inputNroIdentificacion'),
                    inputRazonSocial = this.byId('inputRazonSocial'),
                    fileUpload = this.byId('fileUpload');

                if (proveedor.NroIdentificacion === null) {
                    inputNroIdentificacion.setValueState('Error');
                    this.messages.push({
                        title: bundle.getText("errorEmptyData"),
                        type: coreLibrary.MessageType.Error,
                        subtitle: bundle.getText("NroIdentificacion")
                    });
                } else {
                    inputNroIdentificacion.setValueState('Success');
                }
                if (proveedor.RazonSocial === null) {
                    inputRazonSocial.setValueState('Error');
                    this.messages.push({
                        title: bundle.getText("errorEmptyData"),
                        type: coreLibrary.MessageType.Error,
                        subtitle: bundle.getText("RazonSocial")
                    });
                } else {
                    inputRazonSocial.setValueState('Success');
                }

                const valueUpload = fileUpload.getValue();
                if (valueUpload === '') {
                    fileUpload.setValueState('Error');
                    this.messages.push({
                        title: bundle.getText("errorEmptyData"),
                        type: coreLibrary.MessageType.Error,
                        subtitle: bundle.getText("documento")
                    });
                } else {
                    fileUpload.setValueState('Success');
                }

            },

            _saveFileDocument: async function (nroIden) {
                const t = this;
                try {
                    let updateFile = null;
                    const urlBaseDms = this._getUrlDms();
                    const fileUpload = this.byId('fileUpload');
                    const file = fileUpload.oFileUpload.files[0];
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    const result = await new Promise((resolve, reject) => {
                        reader.onload = function (item) {
                            resolve(item)
                        }
                    })
                    if (result) {
                        let binaryString = result.target.result;
                        let decodedPdfContent = atob(binaryString.split(',')[1]);
                        let byteArray = new Uint8Array(decodedPdfContent.length);
                        for (let i = 0; i < decodedPdfContent.length; i++) {
                            byteArray[i] = decodedPdfContent.charCodeAt(i);
                        }
                        let blob = new Blob([byteArray.buffer], { type: file.type });
                        file.File = blob;
                        const sNameFile = nroIden + '_' + formatter.formatoNombreArchivo(file.name);
                        const requestOptionFile = formatter.getRequestOptionFile(sNameFile, file);
                        updateFile = await this._sendFetch(urlBaseDms, requestOptionFile);
                    }

                    return updateFile;
                } catch (error) {
                    t.validateErrorList(t, error, "Upload File");
                }

            },

            onChangeValueHelp: function (event) {
                const source = event.getSource();
                const value = source.getValue();
                if (value.length > 0)
                    source.setValueState('None');


            }

        })
    });