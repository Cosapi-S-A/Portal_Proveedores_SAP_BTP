sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/ui/core/library",
    "sap/ui/core/routing/History"
], function (
    Controller,
    UIComponent, coreLibrary, History
) {
    "use strict";

    return Controller.extend("ns.cosapi.denegarproveedor.controller.BaseController", {
        getEnviroment: function () {
            const data = 'QAS';
            const env = {
                repository: "2ac5f6e5-9f27-4c41-8e73-9191cf7a90be"
            };
            if (data === 'PRD') {
                env.repository = "0687b0df-65d8-45b5-802c-a5e76db45277"
            }
            return env;
        },

        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },

        /**
         * Convenience method for getting the view model by name.
         * @public
         * @param {string} [sName] the model name
         * @returns {sap.ui.model.Model} the model instance
         */
        getModel: function (sName) {
            return this.getView().getModel(sName);
        },

        /**
         * Convenience method for setting the view model.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel: function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Getter for the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getResourceBundle: function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        onNavBack: function () {
            let oHistory, sPreviewHash;
            oHistory = History.getInstance();
            sPreviewHash = oHistory.getPreviousHash();
            if (sPreviewHash != undefined) {
                window.history.go(-1);
            } else {
                this.getRouter().navTo("RouteMain");
            }
        },

        readEntity: function (odataModel, path, parameters) {
            return new Promise((resolve, reject) => {
                odataModel.read(path, {
                    filters: parameters.filters,
                    urlParameters: parameters.urlParameters,
                    success: resolve,
                    error: reject
                });
            });
        },

        createEntity: function (odataModel, path, data) {
            return new Promise((resolve, reject) => {
                odataModel.create(path, data, {
                    success: resolve,
                    error: reject
                });
            });
        },

        updateEntity: function (odataModel, path, data) {
            return new Promise((resolve, reject) => {
                odataModel.update(path, data, {
                    success: resolve,
                    error: reject
                });
            });
        },

        deleteEntity: function (odataModel, path) {
            return new Promise((resolve, reject) => {
                odataModel.remove(path, {
                    success: resolve,
                    error: reject
                });
            });
        },

        _getUrlDms: function () {
            const env = this.getEnviroment();
            return this._getAppModulePath() + `/apidms/browser/${env.repository}/root/DENEGADOS`;
        },

        _sendFetch: function (sURl, requestOption) {
            return new Promise(function (resolve, reject) {
                fetch(sURl, requestOption)
                    .then(response => response.json())
                    .then(result => {
                        resolve(result);
                    }).catch(error => {
                        reject(error);
                    });
            });
        },

        _sendFetchDelete: function (sURl, requestOption) {
            return new Promise(function (resolve, reject) {
                fetch(sURl, requestOption)
                    .then(result => {
                        resolve(result);
                    }).catch(error => {
                        reject(error);
                    });
            });
        },

        _getAppModulePath: function () {
            const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            const appPath = appId.replaceAll(".", "/");
            return jQuery.sap.getModulePath(appPath);
        },

        /**
            * Metodo para abrir popUp con lista de mensajes de variable global
            */
        _getPopUpMensaje: function (sTitle, oBegginButton, callback, t) {
            if (t === undefined)
                t = this;
            const bundle = this.getResourceBundle();
            if (!sTitle)
                sTitle = bundle.getText('result')
            if (t.messages.length > 0) {
                if (!oBegginButton)
                    oBegginButton = new sap.m.Button({
                        press: async function () {
                            this.getParent().close();
                            t.messages = [];
                            if (callback)
                                callback(t);
                        },
                        text: bundle.getText('close')
                    });
                const model = t.getModel('model');
                model.setProperty("/messages", t.messages);
                t.showMessageView(t, oBegginButton, sTitle);
            }
        },

        getBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);
            return appModulePath;
        },

        showMessageView: function (t, oBeginButton, sTitulo) {
            const oBundle = t.getResourceBundle();
            if (!oBeginButton) {
                oBeginButton = new sap.m.Button({
                    press: function () {
                        this.getParent().close();
                    },
                    text: oBundle.getText('close')
                });
            }

            let oMessageTemplate = new sap.m.MessageItem({
                type: '{type}',
                title: '{title}',
                description: '{description}',
                subtitle: '{subtitle}'
            });
            const model = t.getModel('model');
            t.oMessageView = new sap.m.MessageView({
                showDetailsPageHeader: false,
                itemSelect: function () {
                    oBackButton.setVisible(true);
                },
                items: {
                    path: "/messages",
                    template: oMessageTemplate
                }
            });

            var oBackButton = new sap.m.Button({
                icon: sap.ui.core.IconPool.getIconURI("nav-back"),
                visible: false,
                press: function () {
                    t.oMessageView.navigateBack();
                    this.setVisible(false);
                }
            });
            t.oMessageView.setModel(model);
            t.oDialog = new sap.m.Dialog({
                resizable: true,
                content: t.oMessageView,
                state: coreLibrary.MessageType.Error,
                beginButton: oBeginButton,
                customHeader: new sap.m.Bar({
                    contentLeft: [oBackButton],
                    contentMiddle: [
                        new sap.m.Title({
                            text: sTitulo
                        })
                    ]
                }),
                contentHeight: "50%",
                contentWidth: "50%",
                verticalScrolling: false
            });
            t.oMessageView.navigateBack();
            t.oDialog.open();
        },


        /**
         * Convenience method for dialog confirm 
         * @public
         * @param {sap.ui.core.item} itemTemplate JSON model
         * @param {sap.m.button} buttonAccept 
         * @param {string} sTitle string title
        */
        openDialogConfirm: function (buttonAccept, sTitle, content) {
            const t = this,
                oBundle = t.getResourceBundle();

            if (t.isEmpty(sTitle))
                sTitle = oBundle.getText("confirmAction");

            if (t.isEmpty(content))
                content = new sap.m.Text({
                    text: oBundle.getText('confirmAction'),
                    textAlign: sap.ui.core.TextAlign.Center
                });

            this.dialogConfirm = new sap.m.Dialog({
                title: sTitle,
                content: new sap.m.VBox({
                    items: [
                        content
                    ],
                    justifyContent: "Center",
                    alignItems: "Center"
                }),
                beginButton: buttonAccept,
                endButton: new sap.m.Button({
                    text: oBundle.getText("btnCancel"),
                    press: function () {
                        t.dialogConfirm.close();
                    }.bind(this)
                }),
                afterClose: function () {
                    t.dialogConfirm.destroy();
                    t.dialogConfirm = null;
                }
            });
            this.getView().addDependent(this.dialogConfirm);
            this.dialogConfirm.open();
        },

        /**
         * Convenience method for evaluate empty
         * @public
         * @param {x} valor anything
        */
        isEmpty: function (valor) {
            if (valor === undefined || valor === "" || valor === null)
                return true;

            return false;
        },

        /**
             * Show message busy fragment
             * @param {sap.ui.model.Model} oModel the model instance
             * @public
             */
        showBusyText: function () {
            if (!this._BusyFragment) {
                this._BusyFragment = sap.ui.xmlfragment("ns.cosapi.denegarproveedor.view.fragment.Busy", this);
                this.getView().addDependent(this._BusyFragment);
            }

            this._BusyFragment.open();
        },

        /**
         * Hide message busy fragment
         * @public
         */
        hideBusyText: function () {
            if (this._BusyFragment)
                this._BusyFragment.close();
        },

        /**
         * Agrega a una lista los errores de procesos
         * @param {*} t 
         * @param {*} error 
         * @param {*} sSubtitle 
         */
        validateErrorList: function (t, error, sSubtitle) {
            const oBundle = t.getResourceBundle();
            t.messages.push({
                title: (error.statusText) ? (error.statusText) : sSubtitle,
                type: coreLibrary.MessageType.Error,
                subtitle: oBundle.getText("errorGetData", [sSubtitle])
            });
        },

        getInfoUser: async function () {
            let email = 'ajgrados@indracompany.com',
                userLogin = null;
            if (sap.ushell.Container) {
                const getEmail = await sap.ushell.Container.getService("UserInfo").getEmail();
                if (getEmail)
                    email = getEmail;
            }

            const params = new URLSearchParams({
                filter: `emails.value eq "${email}"`
            });
            const urlBaseDms = this.getBaseURL();
            const urlWithParams = `${urlBaseDms}/scim/Users?${params.toString()}`;
            const fetchUser = await this._sendFetch(urlWithParams, {
                method: 'GET'
            });
            if (fetchUser) 
                userLogin = fetchUser.Resources[0].userName;
            
            return userLogin
        },

    });
});