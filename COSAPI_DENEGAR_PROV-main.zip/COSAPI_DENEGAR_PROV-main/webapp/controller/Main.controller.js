sap.ui.define([
    "./BaseController",
    "./../model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/MessageBox",
    "sap/ui/core/library",
    'sap/ui/export/library',
    'sap/ui/export/Spreadsheet',
],
    function (BaseController, formatter, JSONModel, Filter, MessageBox, coreLibrary, exportLibrary, Spreadsheet) {
        "use strict";
        const EdmType = exportLibrary.EdmType;
        return BaseController.extend("ns.cosapi.denegarproveedor.controller.Main", {
            messages: [],
            onInit: function () {
                const bundle = this.getResourceBundle();
                const model = new JSONModel({
                    messages: [],
                    load: {
                        message: bundle.getText("loadmsg")
                    },
                    BusquedaPro: {
                        NroIdentificacion: null,
                        FechaInicio: null,
                        FechaFin: null
                    },
                    table: {
                        data: []
                    }
                });
                this.setModel(model, "model");

                this.getRouter().getRoute("RouteMain").attachPatternMatched(this._onObjectMatched, this)
                //this._registerForP13n();
            },




            _onObjectMatched: async function () {
                this.showBusyText();

                this._getPopUpMensaje();
                this.hideBusyText();
            },

            onSearch: async function (event, t) {
                if(t === undefined)
                    t = this;
                const model = t.getModel('model');
                const bundle = t.getResourceBundle();
                const filterList = [],
                    filters = [];
                try {
                    model.setProperty("/load/message", bundle.getText('loadmsgSap'));
                    t.showBusyText();
                    const busqueda = model.getProperty("/BusquedaPro");

                    if (busqueda.NroIdentificacion) filterList.push(new Filter("NroIdentificacion", "EQ", busqueda.NroIdentificacion))

                    if (busqueda.FechaInicio && busqueda.FechaFin) {
                        let sFecha = busqueda.FechaInicio + "-" + busqueda.FechaFin
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    } else if (busqueda.FechaInicio && !busqueda.FechaFin) {
                        let sFecha = busqueda.FechaInicio + "-" + busqueda.FechaInicio
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    } else if (!busqueda.FechaInicio && busqueda.FechaFin) {
                        let sFecha = busqueda.FechaFin + "-" + busqueda.FechaFin
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    }

                    if (filterList.length > 0) {
                        filters.push(new Filter({
                            filters: filterList,
                            and: true
                        }))
                    }
                    await t._getReporte(filters)
                } catch (error) {
                    t.validateErrorList(t, error, 'ProveedoresDenegadosSet');
                    t._getPopUpMensaje();
                }
                t.hideBusyText();
            },

            _getReporte: async function (filters) {
                const parameters = {
                    filters: filters,
                    urlParameters: {

                    }
                }
                const model = this.getModel("model");
                const modelRegProveepCrud = this.getOwnerComponent().getModel();
                const aSolicitudPreRegistro = await this.readEntity(modelRegProveepCrud, '/ProveedoresDenegadosSet', parameters)
                model.setProperty("/table/data", aSolicitudPreRegistro.results);
                this.hideBusyText();
            },

            onAdd: function () {
                this._navToForm(0);
            },

            onEdit: function (event) {
                const t = this;
                try {
                    const proveedor = event.getSource().getBindingContext('model').getObject();
                    this._navToForm(proveedor.NroIdentificacion);
                } catch (error) {
                    t.validateErrorList(t, error, 'Edit');
                    this._getPopUpMensaje();
                }

            },

            onAdjunto: async function (event) {
                const t = this;
                const bundle = this.getResourceBundle();
                try {
                    const urlBaseDms = this._getUrlDms();
                    const proveedor = event.getSource().getBindingContext('model').getObject();
                    if (proveedor.IdObjectDms) {
                        const env = this.getEnviroment();
                        const params = new URLSearchParams({
                            //repository_id: env.repository,
                            objectId: proveedor.IdObjectDms,
                            cmisselector: "properties"
                        });
                        const urlWithParams = `${urlBaseDms}/?${params.toString()}`;
                        const getFolder = await this._sendFetch(urlWithParams, {
                            method: 'GET',
                            headers: {
                                "Accept": "application/json",
                                "DataServiceVersion": "2.0"
                            }
                        });

                        if (getFolder) {
                            const rutaDoc = urlBaseDms + '/' + getFolder["cmis:name"].value;
                            window.open(rutaDoc, '_blank');
                        }
                    } else
                        MessageBox.error(bundle.getText('errorObjetctDMS'), {
                            actions: [MessageBox.Action.CLOSE],
                            dependentOn: this.getView()
                        });
                } catch (error) {
                    t.validateErrorList(t, error, 'getDms');
                    this._getPopUpMensaje();
                }

            },

            onDelete: function (event) {
                const t = this;
                const bundle = this.getResourceBundle();
                const proveedor = event.getSource().getBindingContext('model').getObject();
                const buttonAccept = new sap.m.Button({
                    type: sap.m.ButtonType.Emphasized,
                    text: bundle.getText("btnAccept"),
                    press: async function () {
                        t.dialogConfirm.close();
                        const model = t.getModel('model');
                        model.setProperty("/load/message", bundle.getText('loadDelete'))
                        t.showBusyText();
                        const deleteFile = await t._deleteFile(proveedor.IdObjectDms);
                        if (deleteFile)
                            await t._deleteProveedor(proveedor.NroIdentificacion);
                        t.hideBusyText();
                        const oBegginButton = new sap.m.Button({
                            press: async function () {
                                t.messages = [];
                                this.getParent().close();
                                t.onSearch(null, t);
                            },
                            text: bundle.getText('close')
                        });
                        t._getPopUpMensaje(null, oBegginButton);
                    }.bind(this)
                }), text = new sap.m.Text({
                    text: bundle.getText('confirm'),
                    textAlign: sap.ui.core.TextAlign.Center,
                });
                text.addStyleClass('sapUiSmallMargin');

                this.openDialogConfirm(buttonAccept, null, text);
            },

            _deleteFile: async function (fileId) {
                const t = this;
                const bundle = this.getResourceBundle();
                let bDelete = false;
                try {
                    if (fileId) {
                        const urlBaseDms = this._getUrlDms();
                        const requestDeleteFile = formatter.getRequestDelete(fileId);
                        const deleteFile = await this._sendFetchDelete(urlBaseDms, requestDeleteFile);
                        if (deleteFile.status === 200) {
                            bDelete = true;
                            t.messages.push({
                                title: bundle.getText("documento"),
                                type: coreLibrary.MessageType.Success,
                                subtitle: bundle.getText("deleteDMS")
                            })
                        }
                    } else {
                        bDelete = true;
                        t.messages.push({
                            title: bundle.getText("documento"),
                            type: coreLibrary.MessageType.Error,
                            subtitle: bundle.getText("errorObjetctDMS")
                        });
                    }

                } catch (error) {
                    t.validateErrorList(t, error, bundle.getText("documento"));
                }
                return bDelete;
            },

            _deleteProveedor: async function (nro) {
                const t = this;
                const bundle = this.getResourceBundle();
                try {
                    const modelRegProveepCrud = this.getOwnerComponent().getModel();
                    const sPath = `/ProveedoresDenegadosSet(NroIdentificacion='${nro}')`;
                    await this.deleteEntity(modelRegProveepCrud, sPath);
                    t.messages.push({
                        title: bundle.getText("createSAP"),
                        type: coreLibrary.MessageType.Success,
                        subtitle: bundle.getText("deleteSuccess")
                    });
                } catch (error) {
                    t.validateErrorList(t, error, bundle.getText("createSAP"));
                }
            },

            _navToForm: function (nro) {
                this.getRouter().navTo("RouteForm", { NroIdentificacion: nro })
            },

            onDownloadExcel:function(){
                const bundle = this.getResourceBundle();
                try {
                    const table = this.byId('tableReport'),
                        oRowBinding = table.getBinding('items'),
                        aCols = formatter._getDataExcel(table, EdmType),
                        oSettings = {
                            workbook: { columns: aCols },
                            dataSource: oRowBinding,
                            fileName: 'ProveedoresDenegados.xlsx'
                        };

                    const oSheet = new Spreadsheet(oSettings);
                    oSheet.build().finally(function () {
                        oSheet.destroy();
                    });
                } catch (error) {
                    sap.m.MessageBox.error(bundle.getText('errorDownload'));
                }
            }

        });
    });
