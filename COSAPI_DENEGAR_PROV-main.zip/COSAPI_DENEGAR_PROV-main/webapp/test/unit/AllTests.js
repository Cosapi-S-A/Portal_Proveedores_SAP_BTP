sap.ui.define([
	"nscosapi/cosapi_denegar_pprov/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
