sap.ui.define([
	"nscosapi/reporte_pprov/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
