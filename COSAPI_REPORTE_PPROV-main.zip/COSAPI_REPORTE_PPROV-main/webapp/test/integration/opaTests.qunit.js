/* global QUnit */

sap.ui.require(["ns/cosapi/reportepprov/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
