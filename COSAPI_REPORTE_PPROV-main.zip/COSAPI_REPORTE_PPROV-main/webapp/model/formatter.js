sap.ui.define([],
    function () {
        "use strict";

        return {
            /**
             * 
             * @param {*} sText 
             * @returns 
             */
            getKeyTipoProv: function (sText) {
                let sReturn = ""
                switch (sText) {
                    case "Bienes":
                        sReturn = "TpProvBienes"
                        break
                    case "Servicios":
                        sReturn = "TpProvServicios"
                        break
                    case "Subcontratista":
                        sReturn = "TpProvSubcontratista"
                        break
                }
                return sReturn
            },

            /**
             * 
             * @param {*} table 
             * @param {*} bundle 
             * @returns [{
                    key: "nif_col",
                    label: bundle.getText("nro"),
                    path: "Taxnumxl"
                },
                {
                    key: "razonsocial_col",
                    label: bundle.getText("razonsocial"),
                    path: "Fullname"
                }]
             */
            _getDataHelper: function (table, bundle) {
                const columns = table.getColumns();
                const arreglo = [];
                //const pathAux = "model>GruposCategoriasProveedoresSet/results";
                let columnRes = "";
                for (let i = 0; i < columns.length; i++) {
                    const col = columns[i];
                    const pathLabel = col.getAggregation('header').getBindingInfo('text').parts[0].path;
                    let columnName = pathLabel + "_col";
                    if (columnName != "Grupos_col" && columnName != "Categorias_col") {
                        arreglo.push({
                            key: pathLabel + "_col",
                            label: bundle.getText(pathLabel),
                            path: `model>${pathLabel}`
                        });                            
                    }else{
                    //Corregir el Path para las columas de Grupos y Categorias +@INSERT 04.10.2024
                    if (columnName == "Grupos_col") {
                        columnRes = "model>GruposAux";
                    }else if(columnName == "Categorias_col"){
                        columnRes = "model>CategoriasAux";
                    }
                    
                    arreglo.push({
                        key: pathLabel + "_col",
                        label: bundle.getText(pathLabel),
                        path: columnRes
                    });
                    }
                }
                return arreglo;
            },

            _getDataHelperNew: function (bundle) {
                return [
                    {
                        key: "Taxnumxl_col",
                        label: bundle.getText("Taxnumxl"),
                        path: "Taxnumxl"
                    }
                ]
            },



            /**
             * 
             * @param {*} table 
             * {
                    label: 'Text',
                    type: EdmType.String,
                    property: 'Taxnumxl',
                    width: 20,
                    wrap: true
                }
             */
            _getDataExcel: function (table, EdmType, bundle) {
                const columns = table.getColumns();
                const arreglo = [];
                for (let i = 0; i < columns.length; i++) {
                    const col = columns[i];
                    const isVisible = col.getVisible();
                    if (isVisible) {
                        const pathLabel = col.getAggregation('header').getBindingInfo('text').parts[0].path;
                        arreglo.push({
                            label: bundle.getText(pathLabel),
                            type: EdmType.String,
                            property: pathLabel,
                            wrap: true
                        });
                    }

                }
                return arreglo;
            },


        };

    });