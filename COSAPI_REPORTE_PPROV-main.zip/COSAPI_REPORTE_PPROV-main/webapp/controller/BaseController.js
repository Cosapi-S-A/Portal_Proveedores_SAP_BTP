/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/library"
], function (Controller, History, MessageBox, Spreadsheet, coreLibrary) {
	"use strict";
	
	return Controller.extend("ns.cosapi.reportepprov.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

        /**
		 * Show message busy fragment
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @public
		 */
		showBusyText: function () {
			if (!this._BusyFragment) {
				this._BusyFragment = sap.ui.xmlfragment("ns.cosapi.reportepprov.view.fragment.Busy", this);
				this.getView().addDependent(this._BusyFragment);
			}

			this._BusyFragment.open();
		},

		/**
		 * Hide message busy fragment
		 * @public
		 */
		hideBusyText: function () {
			if (this._BusyFragment)
				this._BusyFragment.close();
		},

        showMessageView: function (t, oBeginButton, sTitulo) {
			const oBundle = t.getResourceBundle();
			if (!oBeginButton) {
				oBeginButton = new sap.m.Button({
					press: function () {
						this.getParent().close();
					},
					text: oBundle.getText('close')
				});
			}

			let oMessageTemplate = new sap.m.MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}'
			});
			let oModel = t.getModel('model');
			t.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/messages",
					template: oMessageTemplate
				}
			});

			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					t.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});
			t.oMessageView.setModel(oModel);
			t.oDialog = new sap.m.Dialog({
				resizable: true,
				content: t.oMessageView,
				state: coreLibrary.MessageType.Error,
				beginButton: oBeginButton,
				customHeader: new sap.m.Bar({
					contentLeft: [oBackButton],
					contentMiddle: [
						new sap.m.Title({
							text: sTitulo
						})
					]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});
			t.oMessageView.navigateBack();
			t.oDialog.open();
		},

        /**
		 * Agrega a una lista los errores de procesos
		 * @param {*} t 
		 * @param {*} error 
		 * @param {*} sSubtitle 
		 */
		validateErrorList: function (t, error, sSubtitle) {
			const oBundle = t.getResourceBundle();
			t.messages.push({
				title: (error.statusText) ? (error.statusText) : sSubtitle,
				type: coreLibrary.MessageType.Error,
				subtitle: oBundle.getText("errorGetData", [sSubtitle])
			});
		},

        readEntity: function (odataModel, path, parameters) {
			return new Promise((resolve, reject) => {
				odataModel.read(path, {
					filters: parameters.filters,
					urlParameters: parameters.urlParameters,
					success: resolve,
					error: reject
				});
			});
		},
		_getAppModulePath: function () {
			const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
			const appPath = appId.replaceAll(".", "/");
			return jQuery.sap.getModulePath(appPath);
		},
		formatoFechaMilenio: function (fechaEnMilisegundos) {
            var fecha = new Date(fechaEnMilisegundos);
            
            var dia = fecha.getDate();
            var mes = fecha.getMonth() + 1;
            var año = fecha.getFullYear();
            
            var fechaFormateada = (dia < 10 ? '0' : '') + dia + '.' + (mes < 10 ? '0' : '') + mes + '.' + año;
            
            return fechaFormateada
        },
    });
});