sap.ui.define([
    "./BaseController",
    "./../model/formatter",
    "sap/ui/model/json/JSONModel",
    'sap/ui/model/Filter',
    'sap/ui/model/Sorter',
    'sap/m/p13n/Engine',
    'sap/m/p13n/SelectionController',
    'sap/m/p13n/SortController',
    'sap/m/p13n/GroupController',
    'sap/m/p13n/FilterController',
    'sap/m/p13n/MetadataHelper',
    'sap/m/table/ColumnWidthController',
    'sap/m/ColumnListItem',
    'sap/m/Text',
    'sap/ui/core/library',
    'sap/ui/export/library',
    'sap/ui/export/Spreadsheet',
    "sap/m/MessageBox"
],
    function (BaseController, formatter, JSONModel, Filter, Sorter, Engine, SelectionController, SortController, GroupController, FilterController, MetadataHelper, ColumnWidthController, ColumnListItem, Text, coreLibrary, exportLibrary, Spreadsheet,MessageBox) {
        "use strict";
        let that;
        const EdmType = exportLibrary.EdmType;

        let rutaInicial = "/apidms/browser/"; //Path DMS
        return BaseController.extend("ns.cosapi.reportepprov.controller.Main", {
            messages: [],
            onInit: function () {
                that = this;
                const bundle = this.getResourceBundle();
                const model = new JSONModel({
                    messages: [],
                    load: {
                        message: bundle.getText("loadmsg")
                    },
                    BusquedaPro: {
                        ruc: null,
                        fechaInicio: null,
                        pais: null,
                        estado: [],
                        tipoproveedor:[],
                        razonsocial: null,
                        fechaFin: null,
                        enabledRegion: false,
                        estadoEnvio:null,
                        correoProveedor:null,
                        grupo:null,
                        categoria:null
                    },
                    suggestion: {
                        RazonSocial:[],
                    },
                    
                    listEstadoEnvio: [{
                        key: null
                    },
                    {
                        key: 'ENVIADO'
                    },
                    {
                        key: 'ERROR'
                    },
                    ],
                    table: {
                        data: []
                    }
                });
                this.setModel(model, "model");

                this.getRouter().getRoute("RouteMain").attachPatternMatched(this._onObjectMatched, this)
                this._registerForP13n();
            },

            /**
             * Metodo permite agregar filtros, orden, mover columnas classs Engine
             */
            _registerForP13n: function () {
                const oTable = this.byId("tableReport");
                const bundle = this.getResourceBundle();
                const dataHelper = formatter._getDataHelper(oTable,bundle); //formatter._getDataTable3(); //formatter._getDataHelper(oTable, bundle);
                this.oMetadataHelper = new MetadataHelper(dataHelper);

                Engine.getInstance().register(oTable, {
                    helper: this.oMetadataHelper,
                    controller: {
                        Columns: new SelectionController({
                            targetAggregation: "columns",
                            control: oTable,
                        }),
                        Sorter: new SortController({
                            control: oTable
                        }),
                        Groups: new GroupController({
                            control: oTable
                        }),
                        ColumnWidth: new ColumnWidthController({
                            control: oTable
                        }),
                        Filter: new FilterController({
                            control: oTable
                        })
                    }
                });

                Engine.getInstance().attachStateChange(this.handleStateChange.bind(this));
            },

            onOpenPersoDialog: function (oEvt) {
                this._openPersoDialog(["Columns", "Sorter", "Groups", "Filter"], oEvt.getSource());
            },

            _openPersoDialog: function (aPanels, oSource) {
                var oTable = this.byId("tableReport");

                Engine.getInstance().show(oTable, aPanels, {
                    contentHeight: aPanels.length > 1 ? "50rem" : "35rem",
                    contentWidth: aPanels.length > 1 ? "45rem" : "32rem",
                    source: oSource || oTable
                });
            },

            _getKey: function (oControl) {
                return this.getView().getLocalId(oControl.getId());
            },

            handleStateChange: function (oEvt) {
                const oTable = this.byId("tableReport");
                const oState = oEvt.getParameter("state");

                if (!oState) {
                    return;
                }

                //Update the columns per selection in the state
                this.updateColumns(oState);

                //Create Filters & Sorters
                const aFilter = this.createFilters(oState);
                const aGroups = this.createGroups(oState);
                const aSorter = this.createSorters(oState, aGroups);
                
                const aCells = oState.Columns.map(function (oColumnState) {
                    /*
                    return new Text({
                        text: "{" + this.oMetadataHelper.getProperty(oColumnState.key).path + "}"
                    });
                    */
                    if (oColumnState.key != 'legajoPdf_col') { 
                        return new Text({
                            text: "{" + this.oMetadataHelper.getProperty(oColumnState.key).path + "}"
                        });
                    }else{
                        return new sap.m.Link({
                            text: "{" + this.oMetadataHelper.getProperty(oColumnState.key).path + "}",
                            icon: "sap-icon://pdf-attachment",
                            press: function(oEvent) {that.onLegajoDescarga(oEvent)}  
                        });
                    }
                }.bind(this));

                //rebind the table with the updated cell template
                oTable.bindItems({
                    templateShareable: false,
                    path: 'model>/table/data',
                    sorter: aSorter.concat(aGroups),
                    filters: aFilter,
                    template: new ColumnListItem({
                        cells: aCells
                    })
                });
            },

            createFilters: function (oState) {
                const aFilter = [];
                Object.keys(oState.Filter).forEach((sFilterKey) => {
                    const filterPath = this.oMetadataHelper.getProperty(sFilterKey).path;

                    oState.Filter[sFilterKey].forEach(function (oConditon) {
                        aFilter.push(new Filter(filterPath, oConditon.operator, oConditon.values[0]));
                    });
                });

                this.byId("filterInfo").setVisible(aFilter.length > 0);

                return aFilter;
            },

            createSorters: function (oState, aExistingSorter) {
                const aSorter = aExistingSorter || [];
                oState.Sorter.forEach(function (oSorter) {
                    const oExistingSorter = aSorter.find(function (oSort) {
                        return oSort.sPath === this.oMetadataHelper.getProperty(oSorter.key).path;
                    }.bind(this));

                    if (oExistingSorter) {
                        oExistingSorter.bDescending = !!oSorter.descending;
                    } else {
                        aSorter.push(new Sorter(this.oMetadataHelper.getProperty(oSorter.key).path, oSorter.descending));
                    }
                }.bind(this));

                oState.Sorter.forEach(function (oSorter) {
                    const oCol = this.byId(oSorter.key);
                    if (oSorter.sorted !== false) {
                        oCol.setSortIndicator(oSorter.descending ? coreLibrary.SortOrder.Descending : coreLibrary.SortOrder.Ascending);
                    }
                }.bind(this));

                return aSorter;
            },

            createGroups: function (oState) {
                const aGroupings = [];
                oState.Groups.forEach(function (oGroup) {
                    aGroupings.push(new Sorter(this.oMetadataHelper.getProperty(oGroup.key).path, false, true));
                }.bind(this));

                oState.Groups.forEach(function (oSorter) {
                    const oCol = this.byId(oSorter.key);
                    oCol.data("grouped", true);
                }.bind(this));

                return aGroupings;
            },

            updateColumns: function (oState) {
                const oTable = this.byId("tableReport");

                oTable.getColumns().forEach(function (oColumn, iIndex) {
                    oColumn.setVisible(false);
                    oColumn.setWidth(oState.ColumnWidth[this._getKey(oColumn)]);
                    oColumn.setSortIndicator(coreLibrary.SortOrder.None);
                    oColumn.data("grouped", false);
                }.bind(this));

                oState.Columns.forEach(function (oProp, iIndex) {
                    const oCol = this.byId(oProp.key);
                    oCol.setVisible(true);

                    oTable.removeColumn(oCol);
                    oTable.insertColumn(oCol, iIndex);
                }.bind(this));
            },

            beforeOpenColumnMenu: function (oEvt) {
                const oMenu = this.byId("menu");
                const oColumn = oEvt.getParameter("openBy");
                const oSortItem = oMenu.getQuickActions()[0].getItems()[0];

                oSortItem.setKey(this._getKey(oColumn));
                oSortItem.setLabel(oColumn.getHeader().getText());
                oSortItem.setSortOrder(oColumn.getSortIndicator());

                
            },

            onColumnHeaderItemPress: function (oEvt) {
                const oColumnHeaderItem = oEvt.getSource();
                let sPanel = "Columns";
                if (oColumnHeaderItem.getIcon().indexOf("group") >= 0) {
                    sPanel = "Groups";
                } else if (oColumnHeaderItem.getIcon().indexOf("sort") >= 0) {
                    sPanel = "Sorter";
                } else if (oColumnHeaderItem.getIcon().indexOf("filter") >= 0) {
                    sPanel = "Filter";
                }

                this._openPersoDialog([sPanel]);
            },

            onFilterInfoPress: function (oEvt) {
                this._openPersoDialog(["Filter"], oEvt.getSource());
            },

            onSort: function (oEvt) {
                const oSortItem = oEvt.getParameter("item");
                const oTable = this.byId("tableReport");
                const sAffectedProperty = oSortItem.getKey();
                const sSortOrder = oSortItem.getSortOrder();

                //Apply the state programatically on sorting through the column menu
                //1) Retrieve the current personalization state
                Engine.getInstance().retrieveState(oTable).then(function (oState) {

                    //2) Modify the existing personalization state --> clear all sorters before
                    oState.Sorter.forEach(function (oSorter) {
                        oSorter.sorted = false;
                    });

                    if (sSortOrder !== coreLibrary.SortOrder.None) {
                        oState.Sorter.push({
                            key: sAffectedProperty,
                            descending: sSortOrder === coreLibrary.SortOrder.Descending
                        });
                    }

                    //3) Apply the modified personalization state to persist it in the VariantManagement
                    Engine.getInstance().applyState(oTable, oState);
                });
            },

            onGroup: function (oEvt) {
                const oGroupItem = oEvt.getParameter("item");
                const oTable = this.byId("tableReport");
                const sAffectedProperty = oGroupItem.getKey();

                //1) Retrieve the current personalization state
                Engine.getInstance().retrieveState(oTable).then(function (oState) {

                    //2) Modify the existing personalization state --> clear all groupings before
                    oState.Groups.forEach(function (oSorter) {
                        oSorter.grouped = false;
                    });

                    if (oGroupItem.getGrouped()) {
                        oState.Groups.push({
                            key: sAffectedProperty
                        });
                    }

                    //3) Apply the modified personalization state to persist it in the VariantManagement
                    Engine.getInstance().applyState(oTable, oState);
                });
            },

            onColumnMove: function (oEvt) {
                const oDraggedColumn = oEvt.getParameter("draggedControl");
                const oDroppedColumn = oEvt.getParameter("droppedControl");

                if (oDraggedColumn === oDroppedColumn) {
                    return;
                }

                const oTable = this.byId("tableReport");
                const sDropPosition = oEvt.getParameter("dropPosition");
                const iDraggedIndex = oTable.indexOfColumn(oDraggedColumn);
                const iDroppedIndex = oTable.indexOfColumn(oDroppedColumn);
                const iNewPos = iDroppedIndex + (sDropPosition == "Before" ? 0 : 1) + (iDraggedIndex < iDroppedIndex ? -1 : 0);
                const sKey = this._getKey(oDraggedColumn);

                Engine.getInstance().retrieveState(oTable).then(function (oState) {

                    const oCol = oState.Columns.find(function (oColumn) {
                        return oColumn.key === sKey;
                    }) || {
                        key: sKey
                    };
                    oCol.position = iNewPos;

                    Engine.getInstance().applyState(oTable, {
                        Columns: [oCol]
                    });
                });
            },

            onColumnResize: function (oEvt) {
                const oColumn = oEvt.getParameter("column");
                const sWidth = oEvt.getParameter("width");
                const oTable = this.byId("tableReport");

                const oColumnState = {};
                oColumnState[this._getKey(oColumn)] = sWidth;

                Engine.getInstance().applyState(oTable, {
                    ColumnWidth: oColumnState
                });
            },

            onClearFilterPress: function (oEvt) {
                const oTable = this.byId("tableReport");
                Engine.getInstance().retrieveState(oTable).then(function (oState) {
                    for (var sKey in oState.Filter) {
                        oState.Filter[sKey].map((condition) => {
                            condition.filtered = false;
                        });
                    }
                    Engine.getInstance().applyState(oTable, oState);
                });
            },


            _onObjectMatched: async function () {
                that = this;
                this.showBusyText();
                await this._getListaPaises();
                await this._getListaCategoria();
                await this._getListaGrupos();
                await this._getListaEstado();
                await this._getListaTipoProveedor();
                //await this._getSolicitudActualizar([]);
                // this._getListaValidacion()
                // await this._getSolicitudPreRegistro([])

                // await this._getListaProveedor([])
                this._getPopUpMensaje();
                this.hideBusyText();
            },

            /**
             * Metodo para abrir popUp con lista de mensajes de variable global
             */
            _getPopUpMensaje: function (sTitle, oBegginButton) {
                const t = this;
                const bundle = this.getResourceBundle();
                if (!sTitle)
                    sTitle = bundle.getText('result')
                if (t.messages.length > 0) {
                    if (!oBegginButton)
                        oBegginButton = new sap.m.Button({
                            press: async function () {
                                this.getParent().close();
                                t.messages = [];
                            },
                            text: bundle.getText('close')
                        });
                    const model = t.getModel('model');
                    model.setProperty("/messages", t.messages);
                    t.showMessageView(t, oBegginButton, sTitle);
                }
            },

            _getListaPaises: async function () {
                const t = this;
                const sPath = "/Paises";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaPaises = await this.readEntity(modelPreRegProv, "/ConsultaPaisesSet", {})
                    model.setSizeLimit(9000);
                    model.setProperty(sPath, aListaPaises.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            _getListaCategoria: async function () {
                const t = this;
                const sPath = "/Categorias";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaCategoria = await this.readEntity(modelPreRegProv, "/ConsultaCategoriasSet", {})
                    model.setSizeLimit(9000);
                    model.setProperty(sPath, aListaCategoria.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            _getListaGrupos: async function () {
                const t = this;
                const sPath = "/Grupos";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaGrupos = await this.readEntity(modelPreRegProv, "/ConsultaGruposSet", {})
                    model.setSizeLimit(9000);
                    model.setProperty(sPath, aListaGrupos.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            _getListaEstado: async function () {
                const t = this;
                const sPath = "/Estado";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaEstado = await this.readEntity(modelPreRegProv, "/ConsultaEstadosProvSet", {})
                    model.setProperty(sPath, aListaEstado.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            _getListaValidacion: async function () {
                const t = this;
                const sPath = "/Validacion";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaValidacion = await this.readEntity(modelPreRegProv, "/ConsultaValidacionSet", {})
                    model.setProperty(sPath, aListaValidacion.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            _getListaTipoProveedor: async function () {
                const t = this;
                const sPath = "/TipoProveedor";
                try {
                    const model = this.getModel('model');
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaTipoProveedor = await this.readEntity(modelPreRegProv, "/ConsultaTipoProveedorSet", {})
                    model.setProperty(sPath, aListaTipoProveedor.results)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                }
            },

            onChangePais: async function (event) {
                const t = this;
                const sPath = "/RegionDptp";
                try {
                    const model = this.getModel("model");
                    const cboMainRegionDpto = this.byId('cboMainRegionDpto');
                    this.showBusyText();
                    cboMainRegionDpto.setSelectedKey(null);
                    model.setProperty("/enabledRegion", false);
                    const sKey = event.getSource().getSelectedKey()
                    const filters = [new Filter("Land1", "EQ", `${sKey}`)];
                    const modelPreRegProv = this.getOwnerComponent().getModel();
                    const aListaRegiones = await this.readEntity(modelPreRegProv, "/ConsultaRegionDepartamentoSet", { filters })
                    model.setProperty(sPath, aListaRegiones.results);
                    if (aListaRegiones.results.length > 0)
                        model.setProperty("/enabledRegion", true);
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                    this._getPopUpMensaje();
                }
                this.hideBusyText();
            },

            onSearchNifRazonSocial: async function (event) {
                const value = event.getParameter("suggestValue"),
                    input = event.getSource(),
                    options = {
                        input,
                        field: "Nifrazonsocial",
                        value: value,
                        property: "RazonSocial"
                    };
                if (value.length > 1) {
                    //this.showBusyText();
                    const model = this.getModel("model");
                    const filters = [new Filter(options.field, "EQ", value)];
                    //const modelPreRegProv = this.getOwnerComponent().getModel();
                    //const provisiones = await this.readEntity(modelPreRegProv, `/ConsultaNifRazonSocialSet`, { filters })
                    input.getBinding("suggestionItems").filter(filters);
                    //model.setProperty(`/suggestion/RazonSocial`, provisiones.results)
                    //this.hideBusyText();
                }
            },

            _getFiltrosService: async function (options) {
                const filters = []
                if (options.field) {
                    filters.push(new Filter(options.field, "EQ", options.value))
                }
                options.input.setBusy(true)
                const provisiones = await this.readEntity(oModelPreRegProv, `/ConsultaNifRazonSocialSet`, { filters })
                this.getView().getModel().setProperty(`/${options.property}`, provisiones.results)
                options.input.setBusy(false);
            },

            onSearchActualizar: async function () {
                const t=this;
                const model = this.getModel('model');
                const bundle = this.getResourceBundle();
                const filterList = [],
                    filters = [];
                try {
                    model.setProperty("load/message", bundle.getText('loadmsgSap'))
                    this.showBusyText();
                    const busqueda = model.getProperty("/BusquedaPro");

                    if (busqueda.ruc) filterList.push(new Filter("Taxnumxl", "EQ", busqueda.ruc))

                    if (busqueda.pais) filterList.push(new Filter("Pais", "EQ", busqueda.pais))

                    if (busqueda.ort01) filterList.push(new Filter("Departamento", "EQ", busqueda.ort01))

                    if (busqueda.razonsocial) {
                        if (busqueda.razonsocial) filterList.push(new Filter("RazonSocial", "EQ", busqueda.razonsocial))
                    }

                    if (busqueda.tipoproveedor) {
                        if (busqueda.tipoproveedor.length !== 0) {
                            busqueda.tipoproveedor.map(tipoproveedor => {
                                filterList.push(new Filter(formatter.getKeyTipoProv(tipoproveedor), "EQ", "X"))
                            })
                        }
                    }

                    if (busqueda.grupo) filterList.push(new Filter("Grupos", "EQ", busqueda.grupo))
                    if (busqueda.categoria) filterList.push(new Filter("Categorias", "EQ", busqueda.categoria))

                    if (busqueda.estado) {
                        let aFilterEstado = []
                        if (busqueda.estado.length !== 0) {
                            busqueda.estado.map(estado => {
                                aFilterEstado.push(new Filter("EstadosDeRegistro", "EQ", estado))
                            })

                            filterList.push(new Filter({
                                filters: aFilterEstado,
                                and: false
                            }))
                        }
                    }

                    if(busqueda.correoProveedor) filterList.push(new Filter("CorreoProveedor", "EQ", busqueda.correoProveedor));

                    if(busqueda.estadoEnvio) filterList.push(new Filter("EstadoEnvio", "EQ", busqueda.estadoEnvio))

                    if (busqueda.fechaInicio && busqueda.fechaFin) {
                        let sFecha = busqueda.fechaInicio + "-" + busqueda.fechaFin
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    } else if (busqueda.fechaInicio && !busqueda.fechaFin) {
                        let sFecha = busqueda.fechaInicio + "-" + busqueda.fechaInicio
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    } else if (!busqueda.fechaInicio && busqueda.fechaFin) {
                        let sFecha = busqueda.fechaFin + "-" + busqueda.fechaFin
                        filterList.push(new Filter("FechaDeRegistro", "EQ", sFecha))
                    }
                    /*let filterCodEstado = [
                        new Filter("Codigoestado", "EQ", "01"),
                        new Filter("Codigoestado", "EQ", "02"),
                        new Filter("Codigoestado", "EQ", "04"),
                        new Filter("Codigoestado", "EQ", "05"),
                        new Filter("Codigoestado", "EQ", "06"),
                        new Filter("Codigoestado", "EQ", "07"),
                        new Filter("Codigoestado", "EQ", "08")
                    ]
                    filterList.push(new Filter({
                        filters: filterCodEstado,
                        and: false
                    }))*/

                    if (filterList.length > 0) {
                        filters.push(new Filter({
                            filters: filterList,
                            and: true
                        }))
                    }
                    await this._getReporte(filters)
                } catch (error) {
                    t.validateErrorList(t, error, sPath);
                    this._getPopUpMensaje();
                }
                this.hideBusyText();
            },

            _getReporte: async function (filters) {
                const parameters = {
                    filters: filters,
                    urlParameters: {
                        "$expand": "GruposCategoriasProveedoresSet"
                    }
                }
                const model = this.getModel("model");
                const modelRegProveepCrud = this.getOwnerComponent().getModel("ZMMGS_REGPROVEEPP_CRUD_SRV");
                const aSolicitudPreRegistro = await this.readEntity(modelRegProveepCrud, '/ReporteProveedoresSet', parameters);
                model.setProperty("/table/data", aSolicitudPreRegistro.results);
                this.adjustDataGruposCateg();//+@INSERT
                this.hideBusyText();
            },
            adjustDataGruposCateg: function()
            {
                let group = "";
                let categ = "";
                const textLegajo = this.getResourceBundle().getText('legajoDes');

                const getModel   = this.getView().getModel("model");
                let   odataModel = getModel.getProperty("/table/data");
                if (odataModel.length > 0) {
                    for (let index = 0; index < odataModel.length; index++) {
                        group = "";categ = "";
                        //const element = odataModel[index];
                        odataModel[index].legajoPdf = textLegajo; //+@INSERT

                        if (odataModel[index].GruposCategoriasProveedoresSet) {
                        if (odataModel[index].GruposCategoriasProveedoresSet.results) {
                            if (odataModel[index].GruposCategoriasProveedoresSet.results.length > 0) {
                            
                                const detailGrpCat = odataModel[index].GruposCategoriasProveedoresSet.results;
                                for (let index2 = 0; index2 < detailGrpCat.length; index2++) {
                                    const element = detailGrpCat[index2];
                                    if (group == "") {
                                        group = element.Grupos;
                                    }else{
                                        group = group + "\n" + element.Grupos;
                                    }
        
                                    if (categ == "") {
                                        categ = element.Categorias;
                                    }else{
                                        categ = categ + "\n" + element.Categorias;
                                    }
                                }
                                    odataModel[index].GruposAux      = group;
                                    odataModel[index].CategoriasAux  = categ;
                            }
                        }
                      } 
                    }
                    getModel.setProperty("/table/data", odataModel);
                }

            },

            _getSolicitudActualizar: async function (filters) {
                if (filters.length === 0) {
                    let filterList = [];
                    let filterCodEstado = [
                        new Filter("Codigoestado", "EQ", "01"),
                        new Filter("Codigoestado", "EQ", "02"),
                        new Filter("Codigoestado", "EQ", "04"),
                        new Filter("Codigoestado", "EQ", "05"),
                        new Filter("Codigoestado", "EQ", "06"),
                        new Filter("Codigoestado", "EQ", "07"),
                        new Filter("Codigoestado", "EQ", "08")
                    ]
                    filterList.push(new Filter({
                        filters: filterCodEstado,
                        and: false
                    }))

                    if (filterList.length > 0) {
                        filters.push(new Filter({
                            filters: filterList,
                            and: true
                        }))
                    }
                }

                const parameters = {
                    filters: filters,
                    urlParameters: {
                        "$expand": "ContactoComercialDetSet,InformacionContableDetSet,ExpPrincClientesDetSet,SistemaGestionDetSet,CuentasBancariasDetSet,ReferenciasFinDetSet,SistemasCalidadDetSet,EjecutivosEmpresaDetSet,SistemaGestionSeguridadDetSet,LineaNegocioDetSet,LineaProductoDetSet"
                    }
                }
                const model = this.getModel("model");
                const modelRegProveepCrud = this.getOwnerComponent().getModel("ZMMGS_REGPROVEEPP_CRUD_SRV");
                const aSolicitudPreRegistro = await this.readEntity(modelRegProveepCrud, '/ConsultaTablaProvSet', parameters)
                model.setProperty("/table/data", aSolicitudPreRegistro.results);

            },

            onDownloadExcel: function () {
                const bundle = this.getResourceBundle();
                try {
                    const table = this.byId('tableReport'),
                        oRowBinding = table.getBinding('items'),
                        aCols = formatter._getDataExcel(table, EdmType,bundle),
                        oSettings = {
                            workbook: { columns: aCols },
                            dataSource: oRowBinding,
                            fileName: 'Reporte.xlsx'
                        };

                    const oSheet = new Spreadsheet(oSettings);
                    oSheet.build().finally(function () {
                        oSheet.destroy();
                    });
                } catch (error) {
                    sap.m.MessageBox.error(bundle.getText('errorDownload'));
                }
            },
            onLegajoDescarga: function(oEvent){
                
                const oSource = oEvent.getSource();
                const oDatosSelected = oSource.getBindingContext('model').getObject();
                if (oDatosSelected) {
                    this.getFilesDMSLegajo(oDatosSelected.Taxnumxl,'LEGAJO');
                }

            },
            getFilesDMSLegajo: async function(rucProv,folder){

                let message1 = this.getResourceBundle().getText("msg1");
                let message2 = this.getResourceBundle().getText("msg2");

                try {
                    sap.ui.core.BusyIndicator.show(0);
                    const rptaResult = await this._buscarFolderDocumentacion(rucProv,folder);
                    if (rptaResult.length > 0) {
                        const dataResult = rptaResult[0]; 
                        if (dataResult.type == 'S') {
                            if (dataResult.files) {
                            if (rptaResult.length === 1) {
                                window.open(dataResult.url, '_blank');
                            }else{
                                  const indice = rptaResult.length - 1;  
                                  window.open(rptaResult[indice].url, '_blank');
                            }
                        }else{
                            MessageBox.error(message1);
                        }
                        }else{
                            MessageBox.error(message1);
                        }
                    }   
                    sap.ui.core.BusyIndicator.hide();     
                } catch (error) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageBox.error(message2);
                   console.error("Error Function getFilesDMSLegajo" , error); 
                }
            },
            getUrlDMS: function(rucProv,folder){
                const url = this._getAppModulePath() + rutaInicial + this.onObtenerRepositorioId() + "/root/PROVEEDOR/" + rucProv + "/" + folder;   
                return url
            },
            onObtenerRepositorioId: function () {
                //return "0687b0df-65d8-45b5-802c-a5e76db45277";//PRD
                return "2ac5f6e5-9f27-4c41-8e73-9191cf7a90be";//QAS
            },
            _buscarFolderDocumentacion: async function(rucProv,folder){

                const url = this.getUrlDMS(rucProv,folder);
                let aFiles = [];

                return new Promise((resolve, reject) => {
                    $.ajax({
                        url: url,
                        type: "GET",
                        "mimeType": "multipart/form-data",
                        "contentType": false,
                        "processData": false,
                        success: async function (data) {
                            sap.ui.core.BusyIndicator.hide();
                            let aObjects = JSON.parse(data).objects
                            
                            if (aObjects.length > 0) {
                                for (let i = 0; i < aObjects.length; i++) {
                                    let oObject = aObjects[i]
                                    let sUrl = url + "/" + oObject.object.properties["cmis:name"].value
                                    let oFile = {
                                        id: oObject.object.properties["cmis:objectId"].value,
                                        name: oObject.object.properties["cmis:name"].value,
                                        url: sUrl,
                                        File: null,
                                        dms: true,
                                        fecha_origin: oObject.object.properties["cmis:creationDate"].value,
                                        fecha_creacion: that.formatoFechaMilenio(oObject.object.properties["cmis:creationDate"].value),
                                        type: 'S',
                                        files: true,
                                        message: ''
                                    }
                                    aFiles.push(oFile);
                                }
                                resolve(aFiles);
                            }else{
                                let oFile = { type: 'S', files: false};
                                aFiles.push(oFile);
                            }
                            resolve(aFiles);
                        },
                        error: function (error) {
                            let oFile = { type: 'E', files: false, message : error };
                            aFiles.push(oFile);
                            resolve(aFiles)
                        },
                    })
                });
            }
        });
    });
