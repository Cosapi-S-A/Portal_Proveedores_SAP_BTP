/* global QUnit */

sap.ui.require(["ns/cosapi/visualizardoc/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
