sap.ui.define([
	"nscosapi/visualizardoc/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
