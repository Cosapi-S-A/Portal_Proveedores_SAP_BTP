sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/library",
    "../model/formatter",
],
    function (BaseController, JSONModel, coreLibrary, formatter) {
        "use strict";
        const repositoryId = '2ac5f6e5-9f27-4c41-8e73-9191cf7a90be';//QAS
        //const repositoryId "0687b0df-65d8-45b5-802c-a5e76db45277";//PRD
        const rutaDMS = "/apidms/browser";
        return BaseController.extend("ns.cosapi.visualizardoc.controller.Main", {
            aMessageG: [],
            onInit: function () {
                const bundle = this.getResourceBundle();
                const model = new JSONModel({
                    load: {
                        message: bundle.getText("cargando"),
                        messages: []
                    },
                    detalle: {
                        ruc: null,
                        sociedad: null,
                        serie: null,
                        ConsultaRegFacturasCabSet: null
                    },
                    documentos: {
                        items: []
                    }
                });
                this.setModel(model, "model");
                this.showBusyText();
                this.getRouter().getRoute("RouteMain").attachPatternMatched(this._onObjectMatched, this);
            },

            _onObjectMatched: async function () {
                const ruc = jQuery.sap.getUriParameters().get("ruc");
                const sociedad = jQuery.sap.getUriParameters().get("sociedad");
                const serie = jQuery.sap.getUriParameters().get("serie");

                if (formatter._validateParamsIsNull(ruc, sociedad, serie))
                    return this.getRouter().navTo('notfound', null);

                const model = this.getModel('model');
                model.setProperty("/detalle/ruc", ruc);
                model.setProperty("/detalle/sociedad", sociedad);
                model.setProperty("/detalle/serie", serie);
                await this._getDocumentos(ruc, sociedad, serie);
                this.hideBusyText();
            },

            /**
             * Metodo para obtener documentos
             * @param {*} ruc 
             * @param {*} sociedad 
             * @param {*} serie 
             */
            _getDocumentos: async function (ruc, sociedad, serie) {
                const t = this;
                const bundle = this.getResourceBundle();
                try {
                    const model = this.getModel('model');
                    const url = this._getAppModulePath() + `${rutaDMS}/${repositoryId}/root/FACTURAS/${ruc}/${sociedad}/${serie}`;
                    const adjuntos = await this._getDocumentsDMS(url);
                    const itemsUploadSet = [];
                    for (let i = 0; i < adjuntos.objects.length; i++) {
                        const doc = adjuntos.objects[i];
                        const oFile = {
                            "FileName": doc.object.properties["cmis:name"].value,
                            "objectId": doc.object.properties["cmis:objectId"].value,
                            "Type": doc.object.properties["cmis:contentStreamMimeType"].value,
                            "Ruta": url + '/' +doc.object.properties["cmis:name"].value
                        }
                        oFile.Icon = await formatter._getIconDoc(oFile.Type);
                        itemsUploadSet.push(oFile);
                    }
                    model.setProperty("/documentos/items", itemsUploadSet);
                    
                } catch (error) {
                    return this.getRouter().navTo('notfound', null);

                }
            },

            /**
             * Metodo para obtener promesa API DMS
             * @param {*} url 
             * @returns 
             */
            _getDocumentsDMS: function (url) {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        url: url,
                        contentType: "application/json",
                        success: resolve,
                        error: reject
                    })
                });
            },

            /**
             * Metodo al presionar botton descarga documentos seleccionados
             */
            onDescargarDocumentos: function () {
                const oUploadSet = this.byId("UploadSet");
                const items = oUploadSet.getSelectedItems();
                if(items.length === 0){
                    const bundle = this.getResourceBundle();
                    return sap.m.MessageBox.error(bundle.getText('errorSelectItem'));
                }
                    

                items.forEach(function (oItem) {
                    if (oItem.getListItem().getSelected()) {
                        oItem.download(true);
                    }
                });
            },

            /**
             * Descarga solo un documento al seleccionar
             * @param {*} event 
             */
            onGetDocument:function(event){
                event.preventDefault();
                const { item } = event.getParameters();
                const object = item.getBindingContext('model').getObject();
                if(object.Type.substr(object.Type.length - 3) === 'pdf')
                    window.open(object.Ruta, '_blank');
                else
                    item.download(true);
            }

        });
    });
