sap.ui.define([
	"./BaseController"

], function (BaseController) {
	"use strict";
	return BaseController.extend("ns.cosapi.visualizardoc.controller.NotFound", {
		onInit: function () {
		}
	});
});