sap.ui.define([

],
    function () {
        "use strict";

        return {
            /**
             * Metodo para validar datos de inicio app
             * @param {*} ruc 
             * @param {*} sociedad 
             * @param {*} serie 
             * @returns 
             */
            _validateParamsIsNull: function (ruc = null, sociedad = null, serie = null) {
                let bReturn = false;
                if (ruc === null || sociedad === null || serie === null)
                    bReturn = true;
                return bReturn;
            },

            /**
             * Metodo para formatear icon
             * @param {*} file 
             * @returns 
             */
            _getIconDoc: function (type) {
                let icon = "documents";
                switch (type) {
                    case 'application/pdf':
                        icon = "pdf-reader";
                        break;
                    case 'text/xml':
                        icon = "attachment-html";
                        break;
                    case 'xsl':
                    case 'application/xsl':
                        icon = "excel-attachment";
                        break;
                }
                return `sap-icon://${icon}`;
            }
        };

    });