sap.ui.define([
	"nscosapi/preregistroproveedor/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
